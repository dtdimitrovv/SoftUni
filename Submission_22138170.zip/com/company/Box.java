package com.company;

import java.util.ArrayList;
import java.util.List;

public class Box<E> {
    E item;

    public Box(E item) {
        this.item = item;
    }

    @Override
    public String toString() {
        String itemInStringFormat = this.item.toString();

        String clazz = String.valueOf(itemInStringFormat.getClass()).substring(6);

        return String.format("%s: %s", clazz, itemInStringFormat);
    }
}
