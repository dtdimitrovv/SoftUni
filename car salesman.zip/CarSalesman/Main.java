package CarSalesman;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int numberOfEngines = Integer.parseInt(scanner.nextLine());

        List<Engine> engines = new ArrayList<>(numberOfEngines);

        for (int i = 0; i < numberOfEngines; i++) {
            String[] inputArray = scanner.nextLine().split(" "); // Split the input to different strings so that we can use the information properly

            Engine currentEngine = new Engine();

            currentEngine.setModel(inputArray[0]); // The first word in the array is the model
            currentEngine.setPower(inputArray[1]); // The second word in the array is the power

            // Check if third word exists

            if (inputArray.length >= 3) {

                if (inputArray[2].chars().allMatch(Character::isDigit)) {
                    // This means we are working with displacement
                    currentEngine.setDisplacement(inputArray[2]);
                }
                // In all other cases we will be talking about the efficiency
                else {
                    currentEngine.setEfficiency(inputArray[2]);
                }

                //Check if fourth word exists
                if (inputArray.length == 4) {

                    // Do this for the last part of the string
                    if (inputArray[3].chars().allMatch(Character::isDigit)) {
                        // This means we are working with displacement
                        currentEngine.setDisplacement(inputArray[3]);
                    }
                    // In all other cases we will be talking about the efficiency
                    else {
                        currentEngine.setEfficiency(inputArray[3]);
                    }
                }
            }

            engines.add(currentEngine);
        }

        int numberOfCars = Integer.parseInt(scanner.nextLine());

        List<Car> cars = new ArrayList<>(numberOfCars);

        for (int i = 0; i < numberOfCars; i++) {
            String[] inputArray = scanner.nextLine().split(" "); // Split the input to different strings so that we can use the information properly

            Car currentCar = new Car();
            currentCar.setModel(inputArray[0]);

            Engine currentEngine = new Engine(); // Allocate memory for the engine
            currentEngine.setModel(inputArray[1]); // The second part of the input array is the model of the engine

            // Find the engine in the array of engines
            for (int i1 = 0; i1 < engines.size(); i1++) {
                if (engines.get(i1).getModel().equals(currentEngine.getModel())) {
                    // Set the value of the found engine with filled information to the current engine
                    currentEngine = engines.get(i1);
                }
            }

            currentCar.setEngine(currentEngine); // Push the engine in the car variable

            // Check if weight and color exist
            if (inputArray.length >= 3) {
                if (inputArray[2].chars().allMatch(Character::isDigit)) {
                    // This means we are working with weight
                    currentCar.setWeight(inputArray[2]);
                }
                // In all other cases we will be talking about the color
                else {
                    currentCar.setColor(inputArray[2]);
                }

                //Check if fourth word exists
                if (inputArray.length == 4) {

                    // Do this for the last part of the string
                    if (inputArray[3].chars().allMatch(Character::isDigit)) {
                        // This means we are working with weight
                        currentCar.setWeight(inputArray[3]);
                    }
                    // In all other cases we will be talking about the color
                    else {
                        currentCar.setColor(inputArray[3]);
                    }
                }
            }
            cars.add(currentCar);
        }

        for (int i = 0; i < cars.size(); i++) {
            cars.get(i).printCar();
        }
    }
}
