package RawData;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int n = Integer.parseInt(scanner.nextLine());

        List<Car> cars = new ArrayList<>();

        for (int i = 0; i < n; i++) {
            String[] inputArr = scanner.nextLine().split(" "); // Split the input so we can use the information properly

            String currentModel = inputArr[0];
            int engineSpeed = Integer.parseInt(inputArr[1]);
            int enginePower = Integer.parseInt(inputArr[2]);
            int cargoWeight = Integer.parseInt(inputArr[3]);
            String cargoType = inputArr[4];

            List<Tire> tires = new ArrayList<>();

            for (int j = 5; j < inputArr.length - 1; j += 2) {
                double tirePressure = Double.parseDouble(inputArr[j]);
                int tireAge = Integer.parseInt(inputArr[j + 1]);
                Tire currentTire = new Tire(tirePressure, tireAge);
                tires.add(currentTire);
            }

            cars.add(new Car(currentModel, new Engine(engineSpeed, enginePower), new Cargo(cargoWeight, cargoType), tires));
        }

        String command = scanner.nextLine();

        command = command.toLowerCase(); // Convert it to lower case so that there are no mismatches when checking

        // Check if ti equals 'fragile'
        if (command.equals("fragile")) {

            // Start looping so that you find the cars with fragile cargoType
            for (int i = 0; i < n; i++) {

                Car currentCar = cars.get(i); // Get the current car
                if (currentCar.getCargo().getCargoType().equals("fragile")) {
                    List<Tire> currentTires = currentCar.getTires(); // Store all current tires in one variable

                    // Start iterating so that you can find find a tire will pressure < 1
                    for (int j = 0; j < currentTires.size(); j++) {

                        if (currentTires.get(j).getTirePressure() < 1) {
                            System.out.println(currentCar.getModel());
                            break; // Exit the loop as we don't need to print the car many times
                        }
                    }
                }
            }

        }
        // In all other cases it will be 'flamable'
        else {

            // Start looping so that you find the cars with engine power > 250
            for (int i = 0; i < n; i++) {
                Car currentCar = cars.get(i); // Get the current car

                if (currentCar.getEngine().getEnginePower() > 250) {
                    System.out.println(currentCar.getModel());
                }
            }
        }

//        // Print car
//        for (int i = 0; i < n; i++) {
//            Car currentCar = cars.get(i);
//
//            currentCar.printCar();
//            System.out.println();
//        }
    }
}
