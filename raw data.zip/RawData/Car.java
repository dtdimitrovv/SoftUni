package RawData;

import java.util.ArrayList;
import java.util.List;

public class Car {

    private String model;
    private Engine engine = new Engine();
    private Cargo cargo = new Cargo();
    private List<Tire> tires = new ArrayList<>();

    public Car(String model, Engine engine, Cargo cargo, List<Tire> tires) {
        this.model = model;
        this.engine = engine;
        this.cargo = cargo;
        this.tires = tires;
    }

    public Cargo getCargo() {
        return cargo;
    }

    public String getModel() {
        return model;
    }

    public Engine getEngine() {
        return engine;
    }

    public List<Tire> getTires() {
        return tires;
    }

    public void printCar() {
        System.out.print(model + " ");
        engine.printEngine();
        cargo.printCargo();
        for (int i = 0; i < tires.size(); i++) {
            tires.get(i).printTire();
        }
    }
}
