package com.company;

import java.util.ArrayList;
import java.util.List;

public class Box<E> {
    private List<E> items;

    public Box() {
        this.items = new ArrayList<>();
    }

    public void add(E item){
        this.items.add(item);
    }

    public void swap(int index1,int index2){
        E element1 = this.items.get(index1);
        E element2 = this.items.get(index2);

        this.items.set(index1,element2);
        this.items.set(index2,element1);
    }

    @Override
    public String toString() {
        StringBuilder output = new StringBuilder();

        items.forEach(item -> output.append(String.format("%s: %s%n", getClazz(item), item)));

        return output.toString();
    }

    private String getClazz(E item) {
        return item.getClass().getCanonicalName();
    }
}
