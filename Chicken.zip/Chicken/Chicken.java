package Chicken;

public class Chicken {
    private String name;
    private int age;

    public Chicken(String name, int age) {
        this.setName(name);
        this.setAge(age);
    }

    private void setAge(int age) {
        if (age < 0 || age > 15) {
            throw new IllegalArgumentException("Age should be between 0 and 15.");
        }
        this.age = age;
    }

    private void setName(String name) {
        if (!isValid(name)) {
            throw new IllegalArgumentException("Name cannot be empty.");
        }
        this.name = name;
    }

    private boolean isValid(String name) {
        for (int i = 0; i < name.length(); i++) {
            if (Character.isLetter(name.charAt(i))) {
                return true;
            }
        }
        return false;
    }

    private double calculateProductPerDay() {
        double eggPerDay;

        if (this.age >= 0 && this.age <= 5) {
            eggPerDay = 2;
        } else if (this.age >= 6 && this.age <= 11) {
            eggPerDay = 1;
        } else {
            eggPerDay = 0.75;
        }
        return eggPerDay;
    }

    public double productPerDay() {
        return this.calculateProductPerDay();
    }

    @Override
    public String toString() {
        return String.format("Chicken %s (age %d) can produce %f eggs per day.", this.name, this.age, this.productPerDay());
    }
}
