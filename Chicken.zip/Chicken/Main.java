package Chicken;

import Input.Reader;

public class Main {
    public static void main(String[] args) {
        try {
            Chicken chicken = new Chicken(Reader.readString(), Reader.readInt());
            System.out.println(chicken);
        } catch (IllegalArgumentException ex) {
            System.out.println(ex.getMessage());
        }
    }
}
