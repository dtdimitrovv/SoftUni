package cafe;

import java.util.ArrayList;
import java.util.List;

public class Cafe {
    private String name;
    private List<Employee> employees;
    private int capacity;

    public Cafe(String name, int capacity) {
        this.name = name;
        this.employees = new ArrayList<>();
        this.capacity = capacity;
    }

    public void addEmployee(Employee employee) {
        if (this.employees.size() + 1 <= capacity) {
            this.employees.add(employee);
        }
    }

    public boolean removeEmployee(String name) {
        for (Employee employee : this.employees) {
            if (employee.getName().equals(name)) {
                this.employees.remove(employee);
                return true;
            }
        }
        return false;
    }

    public Employee getOldestEmployee() {
        int max = Integer.MIN_VALUE;
        Employee oldestEmplyee = null;
        for (Employee employee : this.employees) {
            if (employee.getAge() > max) {
                max = employee.getAge();
                oldestEmplyee = employee;
            }
        }
        return oldestEmplyee;
    }

    public Employee getEmployee(String name) {
        for (Employee employee : this.employees) {
            if (employee.getName().equals(name)) {
                return employee;
            }
        }
        return null;
    }

    public int getCount() {
        return this.employees.size();
    }

    public String report() {
        StringBuilder report = new StringBuilder();
        report.append(String.format("Employees working at Cafe %s:\n", this.name));
        this.employees.forEach(e -> report.append(e.toString()).append(System.lineSeparator()));
        return report.toString().trim();
    }
}
