package com.company;

import java.util.ArrayList;
import java.util.List;

public class Box<E extends Comparable<E>> {
    private List<E> items;

    public Box() {
        this.items = new ArrayList<>();
    }

    public void add(E item) {
        this.items.add(item);
    }

    public int getCount(E itemToCompare) {
        int count = 0;

        for (E item : items) {
            if (item.compareTo(itemToCompare) > 0) {
                count++;
            }
        }

        return count;
    }

    @Override
    public String toString() {
        StringBuilder output = new StringBuilder();

        items.forEach(item -> output.append(String.format("%s: %s%n", getClazz(item), item)));

        return output.toString();
    }

    private String getClazz(E item) {
        return item.getClass().getCanonicalName();
    }
}
