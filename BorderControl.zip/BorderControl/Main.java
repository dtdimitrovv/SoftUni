package BorderControl;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        List<Identifiable> identifiableList = new ArrayList<>();

        String command;
        while (!"End".equals(command = scanner.nextLine())) {
            String[] tokens = command.split("\\s+");

            if (tokens.length == 2) {
                String model = tokens[0];
                String id = tokens[1];

                identifiableList.add(new Robot(model, id));
            } else {
                String name = tokens[0];
                int age = Integer.parseInt(tokens[1]);
                String id = tokens[2];

                identifiableList.add(new Citizen(name, age, id));
            }
        }

        String endDigit = scanner.nextLine();

        for (Identifiable identifiable : identifiableList) {
            if (identifiable.getId().endsWith(endDigit)) {
                System.out.println(identifiable.getId());
            }
        }
    }
}
