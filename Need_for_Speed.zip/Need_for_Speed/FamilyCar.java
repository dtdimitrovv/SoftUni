package Need_for_Speed;

public class FamilyCar extends Car {
    public FamilyCar(double fuel, int horsePower) {
        super(fuel, horsePower);
    }
}
