package blueOrigin;

import org.junit.Assert;
import org.junit.Test;

public class SpaceshipTests {

    @Test(expected = NullPointerException.class)
    public void testNullNameShouldFail() {
        new Spaceship(null, 43);
    }

    @Test(expected = NullPointerException.class)
    public void testWhiteSpaceNameShouldFail() {
        new Spaceship("    ", 43);
    }

    @Test
    public void testSetCorrectName() {
        Spaceship spaceship = new Spaceship("test", 43);
        Assert.assertEquals("test", spaceship.getName());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testSetCapacityShouldFail() {
        new Spaceship("test", -1);
    }

    @Test
    public void testSetCorrectCapacity() {
        Spaceship spaceship = new Spaceship("test", 43);
        Assert.assertEquals(43, spaceship.getCapacity());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddAstronautShouldFail() {
        Spaceship spaceship = new Spaceship("test", 0);
        spaceship.add(new Astronaut("Pehho", 45));
    }

    @Test
    public void testAddAstronautShouldWork() {
        Spaceship spaceship = new Spaceship("test", 1);
        spaceship.add(new Astronaut("Pehho", 45));
        Assert.assertEquals(1, spaceship.getCount());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddExistingAstronautShouldFail() {
        Spaceship spaceship = new Spaceship("test", 2);
        spaceship.add(new Astronaut("Pehho", 45));
        spaceship.add(new Astronaut("Pehho", 45));
    }

    @Test
    public void testRemoveNonExistingAstronautShouldFail() {
        Spaceship spaceship = new Spaceship("test", 2);
        spaceship.add(new Astronaut("Pehho", 45));
        Assert.assertFalse(spaceship.remove("Ivan"));
    }

    @Test
    public void testRemoveExistingAstronautShouldWork() {
        Spaceship spaceship = new Spaceship("test", 2);
        spaceship.add(new Astronaut("Pehho", 45));
        Assert.assertTrue(spaceship.remove("Pehho"));
    }
}
