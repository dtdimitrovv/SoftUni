package BirthdayCelebrations;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        List<Birthable> birthableList = new ArrayList<>();

        String command;
        while (!"End".equals(command = scanner.nextLine())) {
            String[] tokens = command.split("\\s+");

            if (tokens[0].equals("Citizen")) {
                String name = tokens[1];
                int age = Integer.parseInt(tokens[2]);
                String id = tokens[3];
                String birthDate = tokens[4];

                birthableList.add(new Citizen(name, age, id, birthDate));
            } else if (tokens[0].equals("Pet")) {
                String name = tokens[1];
                String birthDate = tokens[2];

                birthableList.add(new Pet(name, birthDate));
            }
        }

        String year = scanner.nextLine();

        StringBuilder output = new StringBuilder();

        for (Birthable birthable : birthableList) {
            if (birthable.getBirthDate().endsWith(year)) {
                output.append(birthable.getBirthDate()).append(System.lineSeparator());
            }
        }

        if (output.length() == 0) {
            System.out.println("<no output>");
        } else {
            System.out.println(output.toString().trim());
        }
    }
}
