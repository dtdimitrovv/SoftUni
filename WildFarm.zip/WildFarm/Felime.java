package WildFarm;

public abstract class Felime {
}
