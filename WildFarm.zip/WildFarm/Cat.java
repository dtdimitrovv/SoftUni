package WildFarm;

import java.text.DecimalFormat;
import java.text.NumberFormat;

public class Cat extends Mammal {
    private String breed;

    public Cat(String animalType, String animalName, Double animalWeight, String livingRegion) {
        super(animalType, animalName, animalWeight, livingRegion);
    }

    public void setBreed(String breed) {
        this.breed = breed;
    }

    public String getBreed() {
        return breed;
    }

    @Override
    public void eat(Food food) {
        super.eat(food);
    }

    @Override
    public String makeSound() {
        return ("Meowwww");
    }

    @Override
    public String toString() {
        NumberFormat format = new DecimalFormat("#.##");
        format.setMinimumFractionDigits(0);

        return String.format("%s[%s, %s, %s, %s, %s]", getAnimalType(), getAnimalName(), this.getBreed(),
                        format.format(getAnimalWeight()), getLivingRegion(), getFoodEaten().toString());
    }
}
