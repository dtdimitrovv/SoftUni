package WildFarm;

public abstract class Mammal extends Animal {
    private String livingRegion;

    public Mammal(String animalType, String animalName, Double animalWeight, String livingRegion) {
        super(animalType, animalName, animalWeight);
        this.setLivingRegion(livingRegion);
        super.setFoodEaten(0);
    }

    public void setLivingRegion(String livingRegion) {
        this.livingRegion = livingRegion;
    }

    public String getLivingRegion() {
        return livingRegion;
    }

    @Override
    public abstract String makeSound();

    @Override
    public void eat(Food food) {
        super.setFoodEaten(this.getFoodEaten() + food.getQuantity());
    }
}
