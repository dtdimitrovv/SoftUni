package WildFarm;

import java.text.DecimalFormat;
import java.text.NumberFormat;

public class Tiger extends Mammal {
    private String livingRegion;

    public Tiger(String animalType, String animalName, Double animalWeight, String livingRegion) {
        super(animalType, animalName, animalWeight, livingRegion);
    }

    @Override
    public void eat(Food food) {
        if (food instanceof Vegetable) {
            System.out.println("Tigers are not eating that type of food!");
        } else {
            super.eat(food);
        }
    }

    @Override
    public String toString() {
        NumberFormat format = new DecimalFormat("#.##");
        format.setMinimumFractionDigits(0);

        return String.format("%s[%s, %s, %s, %s]", getAnimalType(), getAnimalName(),
                        format.format(getAnimalWeight()), getLivingRegion(), getFoodEaten().toString());
    }

    @Override
    public String makeSound() {
        return ("ROAAR!!!");
    }
}
