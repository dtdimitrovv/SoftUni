package WildFarm;

import java.text.DecimalFormat;
import java.text.NumberFormat;

public class Zebra extends Mammal {

    public Zebra(String animalType, String animalName, Double animalWeight, String livingRegion) {
        super(animalType, animalName, animalWeight, livingRegion);
    }

    @Override
    public void eat(Food food) {
        if (food instanceof Meat) {
            System.out.println("Zebras are not eating that type of food!");
        } else {
            super.eat(food);
        }
    }

    @Override
    public String makeSound() {
        return ("Zs");
    }

    @Override
    public String toString() {
        NumberFormat format = new DecimalFormat("#.##");
        format.setMinimumFractionDigits(0);

        return String.format("%s[%s, %s, %s, %s]", getAnimalType(), getAnimalName(),
                        format.format(getAnimalWeight()), getLivingRegion(), getFoodEaten().toString());
    }
}
