package WildFarm;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        List<Animal> animalList = new ArrayList<>();

        String command = scanner.nextLine();

        for (int i = 0; !command.equals("End"); i++) {
            if (i % 2 == 0) {
                String[] animalInfo = command.split("\\s+");

                String animalType = animalInfo[0];
                String animalName = animalInfo[1];
                Double animalWeight = Double.valueOf(animalInfo[2]);
                String animalLivingRegion = animalInfo[3];
                String catBreed = "";
                if (animalInfo.length == 5) {
                    catBreed = animalInfo[4];
                }

                if (animalType.equals("Cat")) {
                    Cat cat = new Cat(animalType, animalName, animalWeight, animalLivingRegion);
                    cat.setBreed(catBreed);
                    animalList.add(cat);
                } else if (animalType.equals("Tiger")) {
                    animalList.add(new Tiger(animalType, animalName, animalWeight, animalLivingRegion));
                } else if (animalType.equals("Mouse")) {
                    animalList.add(new Mouse(animalType, animalName, animalWeight, animalLivingRegion));
                } else if (animalType.equals("Zebra")) {
                    animalList.add(new Zebra(animalType, animalName, animalWeight, animalLivingRegion));
                }
            } else {
                String[] foodInfo = command.split("\\s+");

                String foodType = foodInfo[0];
                Integer foodQuantity = Integer.valueOf(foodInfo[1]);

                System.out.println(animalList.get(animalList.size() - 1).makeSound());

                if (foodType.equals("Vegetable")) {
                    Food food = new Vegetable(foodQuantity);
                    animalList.get(animalList.size() - 1).eat(food);
                } else {
                    Food food = new Meat(foodQuantity);
                    animalList.get(animalList.size() - 1).eat(food);
                }

            }
            command = scanner.nextLine();
        }

        for (Animal animal : animalList) {
            System.out.println(animal.toString());
        }
    }
}
