package Telephony;

import java.util.List;

public class Smartphone implements Browsable, Callable {
    private List<String> numbers;
    private List<String> urls;

    public Smartphone(List<String> numbers, List<String> urls) {
        this.numbers = numbers;
        this.urls = urls;
    }

    @Override
    public String browse() {
        StringBuilder output = new StringBuilder();

        for (String url : urls) {
            if (urlIsValid(url)) {
                output.append(String.format("Browsing... %s!", url)).append(System.lineSeparator());
            } else {
                output.append("Invalid URL!").append(System.lineSeparator());
            }
        }

        return output.toString().trim();
    }

    private boolean urlIsValid(String url) {
        for (int i = 0; i < url.length(); i++) {
            if(Character.isDigit(url.charAt(i))){
                return false;
            }
        }
        return true;
    }

    @Override
    public String call() {
        StringBuilder output = new StringBuilder();

        for (String number : numbers) {
            if (numberIsValid(number)) {
                output.append("Calling... ").append(number).append(System.lineSeparator());
            } else {
                output.append("Invalid number!").append(System.lineSeparator());
            }
        }

        return output.toString().trim();
    }

    private boolean numberIsValid(String number) {
        for (int i = 0; i < number.length(); i++) {
            if (!Character.isDigit(number.charAt(i))) {
                return false;
            }
        }
        return true;
    }
}
