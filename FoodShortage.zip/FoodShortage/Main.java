package FoodShortage;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int n = Integer.parseInt(scanner.nextLine());

        List<Citizen> citizens = new ArrayList<>();
        List<Rebel> rebels = new ArrayList<>();

        while (n-- > 0) {
            String[] tokens = scanner.nextLine().split("\\s+");

            if (tokens.length == 4) {
                String name = tokens[0];
                int age = Integer.parseInt(tokens[1]);
                String id = tokens[2];
                String birthDate = tokens[3];

                citizens.add(new Citizen(name, age, id, birthDate));
            } else {
                String name = tokens[0];
                int age = Integer.parseInt(tokens[1]);
                String group = tokens[2];

                rebels.add(new Rebel(name, age, group));
            }
        }

        String name;
        while (!"End".equals(name = scanner.nextLine())) {
            if (citizenIndex(citizens, name) != -1) {
                citizens.get(citizenIndex(citizens, name)).buyFood();
            } else if (rebelIndex(rebels, name) != -1) {
                rebels.get(rebelIndex(rebels, name)).buyFood();
            }
        }

        System.out.println(findWholeFood(citizens, rebels));
    }

    private static int findWholeFood(List<Citizen> citizens, List<Rebel> rebels) {
        int food = 0;
        for (Citizen citizen : citizens) {
            food += citizen.getFood();
        }

        for (Rebel rebel : rebels) {
            food += rebel.getFood();
        }
        return food;
    }

    private static int citizenIndex(List<Citizen> citizens, String name) {
        for (int i = 0; i < citizens.size(); i++) {
            Person citizen = citizens.get(i);
            if (citizen.getName().equals(name)) {
                return i;
            }
        }
        return -1;
    }

    private static int rebelIndex(List<Rebel> rebels, String name) {
        for (int i = 0; i < rebels.size(); i++) {
            Person rebel = rebels.get(i);
            if (rebel.getName().equals(name)) {
                return i;
            }
        }
        return -1;
    }
}
