package companyRoster;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Department {

    private String name;

    private List<Employee> employeesList = new ArrayList<>();

    public String getName() {
        return name;
    }

    public double calculateAverageSalary() {
        double sumOfSalaries = 0;

        for (int i = 0; i < employeesList.size(); i++) {
            sumOfSalaries += employeesList.get(i).getSalary();
        }
        return sumOfSalaries / employeesList.size();
    }

    public int sortByAverageSalaryInAscendingOrder(Department currentDepartment) {
        return Double.compare(this.calculateAverageSalary(), currentDepartment.calculateAverageSalary());
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setEmployee(Employee currentEmployee) {
        this.employeesList.add(currentEmployee);
    }

    public List<Employee> getEmployeesList() {
        return employeesList;
    }

}
