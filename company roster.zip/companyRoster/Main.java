package companyRoster;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int n = Integer.parseInt(scanner.nextLine());

        List<Department> departmentList = new ArrayList<>(n);

        for (int i = 0; i < n; i++) {
            String[] input = scanner.nextLine().split(" "); // Split the input so that we can use the information properly

            Department currentDepartment = new Department();
            currentDepartment.setName(input[3]);

            Employee currentEmployee = new Employee();
            currentEmployee.setName(input[0]);
            currentEmployee.setSalary(Double.parseDouble(input[1]));
            currentEmployee.setPosition(input[2]);
            currentEmployee.setDepartment(input[3]);

            if (4 < input.length) {
                // If the input holds the email
                if (input[4].contains("@")) {
                    currentEmployee.setEmail(input[4]);
                } else {
                    currentEmployee.setAge(Integer.parseInt(input[4]));
                }
            }

            if (5 < input.length) {
                // If the input holds the age
                if (input[5].contains("@")) {
                    currentEmployee.setEmail(input[5]);
                } else {
                    currentEmployee.setAge(Integer.parseInt(input[5]));
                }
            }

            // Check if the department is present in the departmentList
            boolean notPresent = true;
            for (int i1 = 0; i1 < departmentList.size(); i1++) {
                if (departmentList.get(i1).getName().equals(currentDepartment.getName())) {
                    departmentList.get(i1).setEmployee(currentEmployee);
                    notPresent = false;
                    break;
                }
            }

            if (notPresent) {
                // Push the employee in the list of employees of the department
                currentDepartment.setEmployee(currentEmployee);

                // Add the department to the departmentList if it doesn't exist
                departmentList.add(currentDepartment);
            }

        }

        // Sort the list of departments by average salary in ascending order and get the last element
        Collections.sort(departmentList, Department::sortByAverageSalaryInAscendingOrder);

        Department maxAverageSalaryDepartment = departmentList.get(departmentList.size() - 1);

        Collections.sort(maxAverageSalaryDepartment.getEmployeesList(), Employee::sortSalariesInDescendingOrder);

        System.out.println("Highest Average Salary: " + maxAverageSalaryDepartment.getName());
        // Print the result
        for (int i = 0; i < maxAverageSalaryDepartment.getEmployeesList().size(); i++) {
            maxAverageSalaryDepartment.getEmployeesList().get(i).printWholeInfo();
        }
    }
}
