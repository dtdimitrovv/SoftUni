package vetClinic;

import java.util.ArrayList;
import java.util.List;

public class Clinic {
    private List<Pet> data;
    private int capacity;

    public Clinic(int capacity) {
        this.data = new ArrayList<>();
        this.capacity = capacity;
    }

    public void add(Pet pet) {
        if (this.data.size() <= capacity) {
            this.data.add(pet);
        }
    }

    public boolean remove(String name) {
        for (Pet pet : this.data) {
            if (pet.getName().equals(name)) {
                this.data.remove(pet);
                return true;
            }
        }
        return false;
    }

    public Pet getPet(String name, String owner) {
        for (Pet pet : this.data) {
            if (pet.getName().equals(name) && pet.getOwner().equals(owner)) {
                return pet;
            }
        }
        return null;
    }

    public Pet getOldestPet() {
        int max = Integer.MIN_VALUE;
        Pet oldestPet = null;

        for (Pet pet : this.data) {
            if (pet.getAge() > max) {
                max = pet.getAge();
                oldestPet = pet;
            }
        }
        return oldestPet;
    }

    public int getCount() {
        return this.data.size();
    }

    public String getStatistics() {
        StringBuilder report = new StringBuilder();
        report.append("The clinic has the following patients:\n");
        this.data.forEach(pet -> report.append(String.format("%s %s", pet.getName(), pet.getOwner())).append(System.lineSeparator()));
        return report.toString().trim();
    }
}
