package implementations;

import interfaces.List;

import java.util.Arrays;
import java.util.Iterator;

public class ArrayList<E> implements List<E> {

    private Object[] elements = new Object[1];
    private int size = 0;

    @Override
    public boolean add(E element) {
        elements[size] = element;
        size++; // Increase the size

        if (size >= elements.length) {
            // Increase the size of the array
            Object[] newArray = new Object[size * 2];
            for (int i = 0; i < elements.length; i++) {
                newArray[i] = elements[i];
            }
            elements = newArray;
        }

        return true;
    }

    @Override
    public boolean add(int index, E element) {
        if (index < 0 || index > elements.length) {
            return false;
        }
        Object[] newArray = new Object[elements.length];
        for (int i = 0; i < index; i++) {
            newArray[i] = elements[i];
        }
        newArray[index] = element;
        for (int i = index + 1; i < elements.length; i++) {
            newArray[i] = elements[i];
        }
        elements = newArray;

        size++;

        if (size >= elements.length) {
            // Increase the size of the array
            Object[] newArr = new Object[size * 2];
            for (int i = 0; i < elements.length; i++) {
                newArr[i] = elements[i];
            }
            elements = newArr;
        }

        return true;
    }

    @Override
    public E get(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException();
        } else {
            return (E) elements[index];
        }
    }

    @Override
    public E set(int index, E element) {

        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException();
        } else {
            E oldElement = (E) elements[index];

            elements[index] = element;
            return oldElement;
        }
    }

    @Override
    public E remove(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException();
        } else {
            E oldElement = (E) elements[index];

            for (int i = index; i < size - 1; i++) {
                elements[i] = elements[i + 1];
            }

            size--;

            return oldElement;
        }
    }

    @Override
    public int size() {
        return this.size;
    }

    @Override
    public int indexOf(E element) {

        for (int i = 0; i < size; i++) {
            if (elements[i].equals(element)) {
                return i;
            }
        }
        return -1;
    }

    @Override
    public boolean contains(E element) {

        for (int i = 0; i < size; i++) {
            if (elements[i].equals(element)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean isEmpty() {
        if (this.size == 0) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public Iterator<E> iterator() {

        return new Iterator<E>() {
            private int index = 0;

            @Override
            public boolean hasNext() {
                return this.index < size();
            }

            @Override
            public E next() {
                return get(index++);
            }
        };
    }
}
