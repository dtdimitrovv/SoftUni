package implementations;

import interfaces.AbstractQueue;

import java.util.Iterator;

public class Queue<E> implements AbstractQueue<E> {

    static class Node<E> {
        private E element;
        private Node<E> next;

        public Node(E element, Node<E> next) {
            this.element = element;
            this.next = next;
        }

        public Node() {
            this.element = null;
            this.next = null;
        }

        public E getElement() {
            return element;
        }

        public void setElement(E element) {
            this.element = element;
        }

        public Node<E> getNext() {
            return next;
        }

        public void setNext(Node<E> next) {
            this.next = next;
        }
    }

    private Node<E> head ;
    private Node<E> tail ;
    private int size;

    @Override
    public void offer(E element) {
        Node<E> elementToBeAdded = new Node<>(element, null); // Create the new element

        if (head == null) {
            head = elementToBeAdded;
        }
        if (tail != null) {
            tail.setNext(elementToBeAdded);
        }
        tail = elementToBeAdded;

        size++;
    }

    @Override
    public E poll() {
        if (head == null) {
            throw new IllegalStateException();
        } else {
            E elementToDelete = head.getElement();

            head.setNext(head.getNext());

            head = head.getNext();

            size--;

            return elementToDelete;
        }
    }

    @Override
    public E peek() {
        if (head == null) {
            throw new IllegalStateException();
        } else {
            return head.getElement();
        }
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public boolean isEmpty() {
        return size == 0;
    }

    @Override
    public Iterator<E> iterator() {
        return null;
    }
}
