package implementations;

import interfaces.LinkedList;

import java.util.Iterator;

public class SinglyLinkedList<E> implements LinkedList<E> {

    class Node<E> {
        private E element;
        private Node<E> next;

        public Node(E element, Node<E> next) {
            this.element = element;
            this.next = next;
        }

        public void setNext(Node<E> next) {
            this.next = next;
        }

        public E getElement() {
            return element;
        }

        public Node<E> getNext() {
            return next;
        }
    }

    private Node<E> head;
    private Node<E> tail;
    private int size = 0;

    @Override
    public void addFirst(E element) {
        Node<E> newElement = new Node<>(element, null); // Allocate memory for the new element

        // Check if the list is empty
        if (head != null) {
            head.setNext(newElement);
            newElement.setNext(head.getNext());// Get the next element of the head
        }
        head = newElement;

        size++;
    }

    @Override
    public void addLast(E element) {

        Node<E> newElement = new Node<>(element, null); // Allocate memory for the new element

        if (head == null) {
            head = newElement;
        }

        if (tail != null) {
            tail.setNext(newElement);
        }

        tail = newElement;

        size++;
    }

    @Override
    public E removeFirst() {
        if (head == null) {
            throw new IllegalStateException();
        } else {
            E removedElement = head.getElement();

            head = head.getNext();

            size--;

            return removedElement;
        }
    }

    @Override
    public E removeLast() {
        if (tail == null) {
            throw new IllegalStateException();
        } else {
            E lastElement = tail.getElement();

            for (Node<E> i = head; i != null; i = i.getNext()) {
                // Find the last but not least element
                if (i.getNext().getNext() == null) {
                    Node<E> lastButNotLeastElement = new Node<>(i.getElement(), null);
                    tail.setNext(null);
                    tail = lastButNotLeastElement;
                    break;
                }
            }

            size--;

            return lastElement;
        }
    }

    @Override
    public E getFirst() {
        return head.getElement();
    }

    @Override
    public E getLast() {
        return tail.getElement();
    }

    @Override
    public int size() {
        return this.size;
    }

    @Override
    public boolean isEmpty() {
        return this.size == 0;
    }

    @Override
    public Iterator<E> iterator() {
        return null;
    }
}
