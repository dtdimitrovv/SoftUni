package implementations;

import interfaces.AbstractStack;

import java.util.Iterator;

public class Stack<E> implements AbstractStack<E> {

    static class Node<E> {
        private E element;
        private Node<E> previous;

        public Node(E element, Node<E> previous) {
            this.element = element;
            this.previous = previous;
        }

        public E getElement() {
            return element;
        }

        public void setElement(E element) {
            this.element = element;
        }

        public Node<E> getPrevious() {
            return previous;
        }

        public void setPrevious(Node<E> previous) {
            this.previous = previous;
        }
    }

    private Node<E> top = null;
    private int size = 0;

    @Override
    public void push(E element) {
        Node<E> newElement = new Node<>(element, null);

        // If the stack is not empty
        if (top != null) {
            newElement.setPrevious(top.getPrevious());
            top = newElement;
        } else {
            top = newElement;
        }
        size++;
    }

    @Override
    public E pop() {
        if (top == null) {
            throw new IllegalStateException();
        } else {
            E elementToDelete = top.getElement();

            top = top.getPrevious();

            size--;

            return elementToDelete;
        }
    }

    @Override
    public E peek() {
        if (top != null) {
            return top.getElement();
        } else {
            throw new IllegalStateException();
        }
    }

    @Override
    public int size() {
        return this.size;
    }

    @Override
    public boolean isEmpty() {
        return this.size == 0;
    }

    @Override
    public Iterator<E> iterator() {
        return null;
    }
}
