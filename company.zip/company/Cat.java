package com.company;

public class Cat {
    private String type;
    private String name;
    private double feature;

    public Cat(String type, String name, double feature) {
        this.type = type;
        this.name = name;
        this.feature = feature;
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return String.format("%s %s %.2f",type,name,feature);
    }
}
