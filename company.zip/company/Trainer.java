package com.company;

import java.util.*;

public class Trainer {
    //Trainer has a name, number of badges and a collection of pokemon
    private String name;
    private int numberOfBadges;

    public Trainer(String name) {
        this.name = name;
        this.numberOfBadges = 0;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getNumberOfBadges() {
        return numberOfBadges;
    }

    public void setNumberOfBadges(int numberOfBadges) {
        this.numberOfBadges = numberOfBadges;
    }
}
