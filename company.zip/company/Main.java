package com.company;

import java.util.*;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        List<Person> people = new ArrayList<>();

        String command;
        while (!"End".equals(command = scanner.nextLine())) {
            String[] tokens = command.split("\\s+");

            String personName = tokens[0];

            int personIndex = personIndex(people, personName);

            if (personIndex == -1) {
                // If the person doesn't exist, add them to the list of people
                people.add(new Person(personName));
                // Update the index
                personIndex = people.size() - 1;
            }

            // Check if the info is about the company
            if (tokens[1].equals("company")) {
                Company company = new Company(tokens[2], tokens[3], Double.parseDouble(tokens[4]));

                // Update / Set the info for their company as said in the task
                people.get(personIndex).setCompany(company);
            }

            // Check if the info is about the pokemon
            else if (tokens[1].equals("pokemon")) {
                Pokemon pokemon = new Pokemon(tokens[2], tokens[3]);
                people.get(personIndex).getPokemons().add(pokemon);
            }

            // Check if the info is about the parents
            else if (tokens[1].equals("parents")) {
                Parent parent = new Parent(tokens[2], tokens[3]);
                people.get(personIndex).getParents().add(parent);
            }

            // Check if the info is about the children
            else if (tokens[1].equals("children")) {
                Child child = new Child(tokens[2], tokens[3]);
                people.get(personIndex).getChildren().add(child);
            }

            // Check if the info is about the car
            else if (tokens[1].equals("car")) {
                Car car = new Car(tokens[2], Integer.parseInt(tokens[3]));

                // Update / Set the info for their company as said in the task
                people.get(personIndex).setCar(car);
            }
        }

        String personToPrint = scanner.nextLine();
        printPerson(people, personToPrint);
    }

    static int personIndex(List<Person> people, String personToCheck) {

        // Start checking for the person
        for (int i = 0; i < people.size(); i++) {
            if (people.get(i).getName().equals(personToCheck)) {
                return i; // Return the index of the person
            }
        }
        return -1; // Return invalid index if the person is not found
    }

    static void printPerson(List<Person> people, String personToPrint) {
        int personIndex = personIndex(people, personToPrint);

        Person person = people.get(personIndex);

        System.out.println(person.getName());

        System.out.println("Company:");
        if (person.getCompany() != null) {
            System.out.println(person.getCompany().toString());
        }

        System.out.println("Car:");
        if (person.getCar() != null) {
            System.out.println(person.getCar().toString());
        }

        System.out.println("Pokemon:");
        if (person.getPokemons().size() > 0) {
            for (int i = 0; i < person.getPokemons().size(); i++) {
                System.out.println(person.getPokemons().get(i).toString());
            }
        }

        System.out.println("Parents:");
        if (person.getParents().size() > 0) {
            for (int i = 0; i < person.getParents().size(); i++) {
                System.out.println(person.getParents().get(i).toString());
            }
        }

        System.out.println("Children:");
        if (person.getChildren().size() > 0) {
            for (int i = 0; i < person.getChildren().size(); i++) {
                System.out.println(person.getChildren().get(i).toString());
            }
        }
    }
}