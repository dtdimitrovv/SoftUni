package com.company;

import java.util.*;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Store them in a list
        Map<Trainer, List<Pokemon>> trainers = new LinkedHashMap<>();

        // Fill in the list
        fillInTrainers(trainers, scanner);

        proceed(trainers, scanner);

        trainers.entrySet()
                .stream()
                .sorted((first, second) -> second.getKey().getNumberOfBadges() - first.getKey().getNumberOfBadges())
                .forEach(e -> System.out.println(e.getKey().getName() + " " + e.getKey().getNumberOfBadges() + " " + e.getValue().size()));
    }

    private static void proceed(Map<Trainer, List<Pokemon>> trainers, Scanner scanner) {
        String inputElement;
        while (!"End".equals(inputElement = scanner.nextLine())) {
            // Check if a trainer has at least 1 pokemon with the given element
            for (Map.Entry<Trainer, List<Pokemon>> trainer : trainers.entrySet()) {
                if (trainerHasTheElement(trainer.getValue(), inputElement)) {
                    // Increase the number of badges by 1
                    trainer.getKey().setNumberOfBadges(trainer.getKey().getNumberOfBadges() + 1);
                }
                // otherwise all his pokemon lose 10 health
                else {
                    decreasePokemonsHealth(trainer.getValue());
                }
            }
        }
    }

    private static void decreasePokemonsHealth(List<Pokemon> pokemons) {
        for (int i = 0; i < pokemons.size(); ) {
            Pokemon pokemon = pokemons.get(i);

            pokemon.setHealth(pokemon.getHealth() - 10);

            if (pokemon.getHealth() < 0) {
                // Remove the pokemon
                pokemons.remove(pokemon);
            } else {
                i++;
            }
        }
    }

    private static boolean trainerHasTheElement(List<Pokemon> pokemons, String inputElement) {
        for (Pokemon pokemon : pokemons) {
            if (pokemon.getElement().equals(inputElement)) {
                // if a trainer has at least 1 pokemon with the given element, he receives 1 badge - he will already ready it so there is no need to iterate any more
                return true;
            }
        }
        return false;
    }

    static void fillInTrainers(Map<Trainer, List<Pokemon>> trainers, Scanner scanner) {
        String command;
        while (!"Tournament".equals(command = scanner.nextLine())) {
            String[] tokens = command.split("\\s+");

            String trainerName = tokens[0];
            String pokemonName = tokens[1];
            String pokemonElement = tokens[2];
            int pokemonHealth = Integer.parseInt(tokens[3]);

            Trainer currentTrainer = new Trainer(trainerName);

            // Check if the trainers name is present in the map so that we validate whether to add a new trainer to the map or just update the present list of pokemons
            for (Trainer trainer : trainers.keySet()) {
                if (trainer.getName().equals(trainerName)) {
                    // The trainer is present
                    currentTrainer = trainer; // Set the value of the current trainer to the found one
                    break; // Exit the loop as we have found a trainer
                }
            }

            // Put the trainer in case they are absent
            trainers.putIfAbsent(currentTrainer, new ArrayList<>());

            // Get the list of pokemons of each trainer
            List<Pokemon> pokemonListOfCurrentTrainer = trainers.get(currentTrainer);
            pokemonListOfCurrentTrainer.add(new Pokemon(pokemonName, pokemonElement, pokemonHealth));

            // Update the map
            trainers.put(currentTrainer, pokemonListOfCurrentTrainer);
        }
    }
}