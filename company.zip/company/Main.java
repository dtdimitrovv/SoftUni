package com.company;

import java.util.*;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        List<Cat> cats = new ArrayList<>();

        String command;
        while (!"End".equals(command = scanner.nextLine())) {
            String[] tokens = command.split("\\s+");

            String type = tokens[0];
            String name = tokens[1];
            double feature = Double.parseDouble(tokens[2]);

            cats.add(new Cat(type,name,feature));
        }

        String catToPrint = scanner.nextLine();

        for (Cat cat : cats) {
            if(cat.getName().equals(catToPrint)){
                System.out.println(cat);
            }
        }
    }
}