package com.company;

public class BankAccount {
    private int ID;
    private double balance;
    private static double interestRate = 0.02;
    private static int accountsCount = 1;

    public BankAccount() {
        this.ID = accountsCount;
        accountsCount++;
    }

    public static void setInterestRate(double interestRate) {
        BankAccount.interestRate = interestRate;
    }

    public int getID() {
        return ID;
    }

    public double getInterestRate(int years) {
        return BankAccount.interestRate * years * this.balance;
    }

    public void deposit(double amount) {
        this.balance += amount;
    }
}
