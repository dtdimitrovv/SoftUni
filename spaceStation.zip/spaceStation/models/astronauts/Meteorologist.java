package spaceStation.models.astronauts;

public class Meteorologist extends BaseAstronaut {
    public Meteorologist(String name) {
        super(name, 90);
    }
}
