package spaceStation.models.mission;

import spaceStation.models.astronauts.Astronaut;
import spaceStation.models.astronauts.BaseAstronaut;
import spaceStation.models.planets.Planet;

import java.util.Collection;
import java.util.List;

public class MissionImpl implements Mission {

    // !!!!!!!!!!!!!!!!!!!!!!!!!!!!! due to breath
    @Override
    public void explore(Planet planet, List<Astronaut> astronauts) {
        for (Astronaut astronaut : astronauts) {
            if (astronaut.canBreath()) {
                while (astronaut.canBreath()) {
                    if (!planet.getItems().isEmpty()) {
                        String item = planet.getItems().remove(0);
                        astronaut.getBag().getItems().add(item);
                        astronaut.breath();
                    } else {
                        return;
                    }
                }
            }
        }
    }
}
