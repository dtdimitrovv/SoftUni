package spaceStation.repositories;

import spaceStation.models.planets.Planet;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class PlanetRepository implements Repository {
    private List<Planet> planets;

    public PlanetRepository() {
        this.planets = new ArrayList<>();
    }

    @Override
    public Collection getModels() {
        return Collections.unmodifiableCollection(this.planets);
    }

    @Override
    public void add(Object model) {
        this.planets.add((Planet) model);
    }

    @Override
    public boolean remove(Object model) {
        return this.planets.remove(model);
    }

    @Override
    public Object findByName(String name) {
        for (Planet planet : this.planets) {
            if (planet.getName().equals(name)) {
                return planet;
            }
        }
        return null;
    }
}
