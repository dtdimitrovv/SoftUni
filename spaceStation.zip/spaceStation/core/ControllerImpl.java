package spaceStation.core;

import spaceStation.models.astronauts.*;
import spaceStation.models.mission.Mission;
import spaceStation.models.mission.MissionImpl;
import spaceStation.models.planets.Planet;
import spaceStation.models.planets.PlanetImpl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static spaceStation.common.ConstantMessages.*;
import static spaceStation.common.ExceptionMessages.*;

public class ControllerImpl implements Controller {
    private List<BaseAstronaut> astronauts;
    private List<Planet> planets;
    private int exploredPlanets;

    public ControllerImpl() {
        this.astronauts = new ArrayList<>();
        this.planets = new ArrayList<>();
        this.exploredPlanets = 0;
    }

    @Override
    public String addAstronaut(String type, String astronautName) {
        if (type.equals("Biologist")) {
            this.astronauts.add(new Biologist(astronautName));
        } else if (type.equals("Geodesist")) {
            this.astronauts.add(new Geodesist(astronautName));
        } else if (type.equals("Meteorologist")) {
            this.astronauts.add(new Meteorologist(astronautName));
        } else {
            throw new IllegalArgumentException(ASTRONAUT_INVALID_TYPE);
        }

        return String.format(ASTRONAUT_ADDED, type, astronautName);
    }

    @Override
    public String addPlanet(String planetName, String... items) {
        PlanetImpl newPlanet = new PlanetImpl(planetName);

        List<String> itemsToAdd = new ArrayList<>();

        for (int i = 0; i < items.length; i++) {
            itemsToAdd.add(items[i]);
        }

        newPlanet.setItems(itemsToAdd);

        this.planets.add(newPlanet);

        return String.format(PLANET_ADDED, planetName);
    }

    @Override
    public String retireAstronaut(String astronautName) {
        for (Astronaut astronaut : this.astronauts) {
            if (astronaut.getName().equals(astronautName)) {
                this.astronauts.remove(astronaut);
                return String.format(ASTRONAUT_RETIRED, astronautName);
            }
        }
        return String.format(ASTRONAUT_DOES_NOT_EXIST, astronautName);
    }

    @Override
    public String explorePlanet(String planetName) {
        Planet planetToExplore = findPlanetByName(planetName);

        List<Astronaut> appropriateAstronauts = new ArrayList<>();

        for (Astronaut astronaut : this.astronauts) {
            if (astronaut.getOxygen() > 60) {
                appropriateAstronauts.add(astronaut);
            }
        }

        if (appropriateAstronauts.isEmpty()) {
            throw new IllegalArgumentException(PLANET_ASTRONAUTS_DOES_NOT_EXISTS);
        } else {
            this.exploredPlanets++;
        }

        Mission mission = new MissionImpl();

        mission.explore(planetToExplore, appropriateAstronauts);

        int deadAstronauts = 0;

        // Count the number of dead astronauts
        for (Astronaut astronaut : appropriateAstronauts) {
            if (astronaut.getOxygen() <= 0) {
                deadAstronauts++;
            }
        }

        return String.format(PLANET_EXPLORED, planetName, deadAstronauts);
    }

    private Planet findPlanetByName(String planetName) {
        for (Planet planet : this.planets) {
            if (planet.getName().equals(planetName)) {
                return planet;
            }
        }
        return null;
    }

    @Override
    public String report() {
        StringBuilder output = new StringBuilder();

        output.append(String.format("%d planets were explored!\n", this.exploredPlanets));

        output.append("Astronauts info:\n");

        for (BaseAstronaut astronaut : this.astronauts) {
            output.append(astronaut.toString());
        }

        return output.toString().trim();
    }
}
