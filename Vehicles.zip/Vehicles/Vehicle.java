package Vehicles;

import java.text.DecimalFormat;
import java.text.NumberFormat;

public class Vehicle {
    private String type;
    private double fuelQuantity;
    private double fuelConsumption;

    public Vehicle(String type, double fuelQuantity, double fuelConsumption) {
        this.type = type;
        this.fuelQuantity = fuelQuantity;
        this.fuelConsumption = fuelConsumption;
    }

    public double getFuelQuantity() {
        return fuelQuantity;
    }

    public void setFuelQuantity(double fuelQuantity) {
        this.fuelQuantity = fuelQuantity;
    }

    public double getFuelConsumption() {
        return fuelConsumption;
    }

    public void setFuelConsumption(double fuelConsumption) {
        this.fuelConsumption = fuelConsumption;
    }

    public void drive(double distance) {
        NumberFormat format = new DecimalFormat("#.##");
        format.setMinimumFractionDigits(0);

        double leftFuelAfterTravelling = this.fuelQuantity - distance * this.fuelConsumption;
        if (leftFuelAfterTravelling >= 0) {
            System.out.printf("%s travelled %s km\n", this.type, format.format(distance));
            this.setFuelQuantity(leftFuelAfterTravelling);
        } else {
            System.out.printf("%s needs refueling\n", this.type);
        }
    }

    public void refuel(double litres) {
        this.setFuelQuantity(this.getFuelQuantity() + litres);
    }
}
