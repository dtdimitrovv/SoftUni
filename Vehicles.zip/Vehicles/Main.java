package Vehicles;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] carInput = scanner.nextLine().split("\\s+");
        Car car = new Car(Double.parseDouble(carInput[1]), Double.parseDouble(carInput[2]));

        String[] truckInput = scanner.nextLine().split("\\s+");
        Truck truck = new Truck(Double.parseDouble(truckInput[1]), Double.parseDouble(truckInput[2]));

        int n = Integer.parseInt(scanner.nextLine());
        while (n-- > 0) {
            String[] tokens = scanner.nextLine().split("\\s+");

            String type = tokens[0];
            String vehicle = tokens[1];
            double num = Double.parseDouble(tokens[2]);

            if (type.equals("Drive")) {
                if (vehicle.equals("Car")) {
                    car.drive(num);
                } else {
                    truck.drive(num);
                }
            } else {
                if (vehicle.equals("Car")) {
                    car.refuel(num);
                } else {
                    truck.refuel(num);
                }
            }
        }

        System.out.printf("Car: %.2f\n", car.getFuelQuantity());
        System.out.printf("Truck: %.2f", truck.getFuelQuantity());
    }
}
