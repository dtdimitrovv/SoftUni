package Vehicles;

public class Car extends Vehicle {
    public Car(double fuelQuantity, double fuelConsumption) {
        super("Car", fuelQuantity, fuelConsumption);
        super.setFuelConsumption(super.getFuelConsumption() + 0.9);
    }
}
