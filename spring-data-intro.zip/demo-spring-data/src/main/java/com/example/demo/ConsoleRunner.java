package com.example.demo;

import com.example.demo.models.Author;
import com.example.demo.services.AuthorService;
import com.example.demo.services.BookService;
import com.example.demo.services.CategoryService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Component
public class ConsoleRunner implements CommandLineRunner {
    private final CategoryService categoryService;
    private final AuthorService authorService;
    private final BookService bookService;

    public ConsoleRunner(CategoryService categoryService, AuthorService authorService, BookService bookService) {
        this.categoryService = categoryService;
        this.authorService = authorService;
        this.bookService = bookService;
    }

    @Override
    public void run(String... args) throws Exception {
        seedData();
    }

    private void seedData() throws IOException {
        this.categoryService.seedCategories();
        this.authorService.seedAuthors();
        this.bookService.seedBooks();
    }

    private void printTitlesOfBooksAfterYear(int year) {
        this.bookService
                .findTitlesOfBooksAfterYear(2000)
                .forEach(book -> {
                    System.out.println(book.getTitle());
                });
    }

    private void printAuthorsNameWithOneBookReleaseBefore1990(int year) {
        this.bookService
                .findAuthorsNameWithOneBookReleaseBefore1990(year)
                .forEach(book -> {
                    System.out.println(book.getAuthor().getFirstName() + " " + book.getAuthor().getLastName());
                });
    }
}
