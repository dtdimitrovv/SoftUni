package com.example.demo.models;

public enum AgeRestriction {
    MINOR,
    TEEN,
    ADULT
}
