package com.example.demo.services.impl;

import com.example.demo.models.Author;
import com.example.demo.repositories.AuthorRepository;
import com.example.demo.services.AuthorService;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.Collectors;

@Service
public class AuthorServiceImpl implements AuthorService {
    private final AuthorRepository authorRepository;

    public AuthorServiceImpl(AuthorRepository authorRepository) {
        this.authorRepository = authorRepository;
    }

    @Override
    public void seedAuthors() throws IOException {
        if (this.authorRepository.count() > 0) {
            return;
        }
        List<String> authors = Files
                .readAllLines(Path.of("D:\\Spring Data\\demo-spring-data\\src\\main\\resources\\files\\" + "authors.txt"))
                .stream()
                .filter(str -> !str.isBlank())
                .collect(Collectors.toList());
        authors.forEach(authorLine -> {
            String[] authorsTokens = authorLine.split("\\s+");
            Author author = new Author();
            author.setFirstName(authorsTokens[0]);
            author.setLastName(authorsTokens[1]);
            this.authorRepository.save(author);
        });
    }

    @Override
    public Author getRandomAuthor() {
        long randomId = ThreadLocalRandom.current().nextLong(1, this.authorRepository.count() + 1);
        return this.authorRepository.findById(randomId).orElse(null);
    }
}
