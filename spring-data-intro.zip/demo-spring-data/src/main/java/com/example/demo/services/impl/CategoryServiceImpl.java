package com.example.demo.services.impl;

import com.example.demo.models.Category;
import com.example.demo.repositories.CategoryRepository;
import com.example.demo.services.CategoryService;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.Collectors;

@Service
public class CategoryServiceImpl implements CategoryService {
    private final CategoryRepository categoryRepository;

    public CategoryServiceImpl(CategoryRepository categoryRepository) {
        this.categoryRepository = categoryRepository;
    }

    @Override
    public void seedCategories() throws IOException {
        if (this.categoryRepository.count() > 0) {
            return;
        }
        List<String> categories = Files
                .readAllLines(Path.of("D:\\Spring Data\\demo-spring-data\\src\\main\\resources\\files\\" + "categories.txt"))
                .stream()
                .filter(s -> !s.isBlank())
                .collect(Collectors.toList());
        categories.forEach(categoryName -> {
            Category newCategory = new Category();
            newCategory.setName(categoryName);
            this.categoryRepository.save(newCategory);
        });
    }

    @Override
    public Set<Category> getRandomCategories() {
        Set<Category> categories = new HashSet<>();
        int numberOfCategories = ThreadLocalRandom.current().nextInt(1, 3);
        for (int i = 0; i < numberOfCategories; i++) {
            categories.add(this.categoryRepository
                    .findById(ThreadLocalRandom.current().nextLong(1, this.categoryRepository.count() + 1))
                    .orElse(null));
        }
        return categories;
    }
}
