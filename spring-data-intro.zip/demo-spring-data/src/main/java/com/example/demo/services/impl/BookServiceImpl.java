package com.example.demo.services.impl;

import com.example.demo.models.*;
import com.example.demo.repositories.BookRepository;
import com.example.demo.services.AuthorService;
import com.example.demo.services.BookService;
import com.example.demo.services.CategoryService;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class BookServiceImpl implements BookService {
    private final BookRepository bookRepository;
    private final AuthorService authorService;
    private final CategoryService categoryService;

    public BookServiceImpl(BookRepository bookRepository, AuthorService authorService, CategoryService categoryService) {
        this.bookRepository = bookRepository;
        this.authorService = authorService;
        this.categoryService = categoryService;
    }

    @Override
    public void seedBooks() throws IOException {
        if (this.bookRepository.count() > 0) {
            return;
        }
        List<String> books = Files.readAllLines(Path.of("D:\\Spring Data\\demo-spring-data\\src\\main\\resources\\files\\" + "books.txt"))
                .stream()
                .filter(str -> !str.isBlank())
                .collect(Collectors.toList());

        books.forEach(bookInput -> {
            String[] data = bookInput.split("\\s+");

            EditionType editionType = EditionType.values()[Integer.parseInt(data[0])];
            LocalDate releaseDate = LocalDate.parse(data[1], DateTimeFormatter.ofPattern("d/M/yyyy"));
            int copies = Integer.parseInt(data[2]);
            BigDecimal price = new BigDecimal(data[3]);
            AgeRestriction ageRestriction = AgeRestriction.values()[Integer.parseInt(data[4])];
            String title = Arrays.stream(data)
                    .skip(5) // Skip first 5
                    .collect(Collectors.joining(" "));

            Author author = this.authorService.getRandomAuthor();
            Set<Category> categories = this.categoryService.getRandomCategories();

            Book book = new Book(title, editionType, price, copies, releaseDate, ageRestriction, author, categories);
            this.bookRepository.save(book);
        });
    }

    @Override
    public List<Book> findAuthorsNameWithOneBookReleaseBefore1990(int year) {
        return bookRepository.findDistinctByReleaseDateBefore(LocalDate.of(year, 1, 1));
    }

    @Override
    public List<Book> findTitlesOfBooksAfterYear(int year) {
        return bookRepository.findDistinctByReleaseDateAfter(LocalDate.of(year, 1, 1));
    }
}
