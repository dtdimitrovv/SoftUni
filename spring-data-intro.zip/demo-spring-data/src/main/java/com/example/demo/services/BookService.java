package com.example.demo.services;

import com.example.demo.models.Book;

import java.io.IOException;
import java.util.List;

public interface BookService {
    void seedBooks() throws IOException;

    List<Book> findAuthorsNameWithOneBookReleaseBefore1990(int year);

    List<Book> findTitlesOfBooksAfterYear(int year);
}
