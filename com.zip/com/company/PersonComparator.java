package com.company;

import java.util.Comparator;

public class PersonComparator implements Comparator<Person> {

    @Override
    public int compare(Person first, Person second) {
        int result = first.getName().compareTo(second.getName());
        result += Integer.compare(first.getAge(), second.getAge());
        return result;
    }
}
