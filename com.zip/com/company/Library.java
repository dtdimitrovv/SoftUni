package com.company;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Library implements Iterable<Book> {
    private List<Book> books;

    public Library() {
        this.books = new ArrayList<>();
    }

    public void add(Book book) {
        this.books.add(book);
    }

    private static class BookIterator implements Iterator<Book> {
        private int i = 0;
        private List<Book> books;

        public BookIterator(List<Book> books) {
            this.books = books;
        }

        @Override
        public boolean hasNext() {
            return i < this.books.size();
        }

        @Override
        public Book next() {
            return this.books.get(i++);
        }
    }

    public Iterator<Book> iterator() {
        // return new BookIterator(this.books);

        return new Iterator<Book>() {
            private int i = 0;

            @Override
            public boolean hasNext() {
                return i < books.size();
            }

            @Override
            public Book next() {
                return books.get(i++);
            }
        };
    }
}
