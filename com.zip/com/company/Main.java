package com.company;

import java.util.*;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Box<String> box = new Box<>();

        String command;
        while (!"END".equals(command = scanner.nextLine())) {
            String[] tokens = command.split("\\s+");

            if (tokens[0].equals("Add")) {
                box.add(tokens[1]);
            }

            else if (tokens[0].equals("Remove")) {
                box.remove(Integer.parseInt(tokens[1]));
            }

            else if (tokens[0].equals("Contains")) {
                System.out.println(box.contains(tokens[1]));
            }

            else if (tokens[0].equals("Swap")) {
                box.swap(Integer.parseInt(tokens[1]),Integer.parseInt(tokens[2]));
            }

            else if (tokens[0].equals("Greater")) {
                System.out.println(box.countGreaterThan(tokens[1]));
            }

            else if (tokens[0].equals("Max")) {
                System.out.println(box.getMax());
            }

            else if (tokens[0].equals("Min")) {
                System.out.println(box.getMin());
            }

            else if (tokens[0].equals("Print")) {
                if(box.size()!=0){
                    System.out.println(box);
                }
            }
        }
    }
}