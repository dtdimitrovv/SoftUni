package com.company;

import java.util.*;

public class Main {

    public static void main(String[] args) throws Exception {
        Scanner scanner = new Scanner(System.in);

        List<Clinic> clinics = new ArrayList<>();
        List<Pet> pets = new ArrayList<>();

        int numberOfCommands = Integer.parseInt(scanner.nextLine());

        for (int i = 0; i < numberOfCommands; i++) {
            String[] input = scanner.nextLine().split("\\s+");

            if (input[0].equals("Create")) {
                if (input[1].equals("Pet")) {
                    pets.add(new Pet(input[2], Integer.parseInt(input[3]), input[4]));
                } else if (input[1].equals("Clinic")) {
                    int rooms = Integer.parseInt(input[3]);
                    if (rooms % 2 != 0) {
                        clinics.add(new Clinic(input[2], rooms));
                    } else {
                        System.out.println("Invalid Operation!");
                    }
                }
            }

            //
            else if (input[0].equals("Add")) {
                String petName = input[1];
                String clinicName = input[2];

                // Find the pet in the list of pets
                int indexOfPetToAdd = findPetIndex(petName, pets);

                // Find the clinic in the list of clinics
                int indexOfClinicToAdd = findClinicIndex(clinicName, clinics);

                if (indexOfPetToAdd != -1 && indexOfClinicToAdd != -1) {
                    Pet petToAdd = pets.get(indexOfPetToAdd);
                    System.out.println(clinics.get(indexOfClinicToAdd).Add(petToAdd));
                } else {
                    System.out.println("Invalid Operation!");
                }
            }

            //
            else if (input[0].equals("Release")) {
                String clinicName = input[1];
                int indexOfClinicToRelease = findClinicIndex(clinicName, clinics);
                if (indexOfClinicToRelease != -1) {
                    System.out.println(clinics.get(indexOfClinicToRelease).ReleasePet());
                } else {
                    System.out.println("Invalid Operation!");
                }
            }

            //
            else if (input[0].equals("HasEmptyRooms")) {
                String clinicName = input[1];
                int indexOfClinicToCheck = findClinicIndex(clinicName, clinics);
                if (indexOfClinicToCheck != -1) {
                    System.out.println(clinics.get(indexOfClinicToCheck).HasEmptyRooms());
                } else {
                    System.out.println("Invalid Operation!");
                }
            }

            //
            else if (input[0].equals("Print")) {
                // Print each room of the clinic

                String clinicName = input[1];
                int indexOfClinicToPrint = findClinicIndex(clinicName, clinics);
                if (indexOfClinicToPrint != -1) {
                    if (input.length == 2) {
                        clinics.get(indexOfClinicToPrint).Print();
                    } else if (input.length == 3) {
                        int roomNumber = Integer.parseInt(input[2]);
                        clinics.get(indexOfClinicToPrint).PrintRoom(roomNumber-1); // roomNumber - 1 as we start counting from 0
                    }
                } else {
                    System.out.println("Invalid Operation!");
                }
            }
        }
    }


    private static int findClinicIndex(String clinicName, List<Clinic> clinics) {
        for (int i = 0, clinicsSize = clinics.size(); i < clinicsSize; i++) {
            Clinic currentClinic = clinics.get(i);
            if (currentClinic.getName().equals(clinicName)) {
                return i;
            }
        }
        return -1;
    }

    private static int findPetIndex(String petName, List<Pet> pets) {
        // Search for the pet in the list of pets
        for (int i = 0, petsSize = pets.size(); i < petsSize; i++) {
            Pet currentPet = pets.get(i);
            if (currentPet.getName().equals(petName)) {
                return i;
            }
        }
        return -1;
    }
}