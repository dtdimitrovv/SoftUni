package com.company;

import java.util.*;
import java.util.stream.Collectors;

public class Main {

    public static void main(String[] args) throws Exception {
        Scanner scanner = new Scanner(System.in);

        TreeSet<Person> treeSet = new TreeSet<>(new PersonComparator());
        HashSet<Person> hashSet = new HashSet<>();

        int n = Integer.parseInt(scanner.nextLine());

        while (n-- > 0) {
            String[] tokens = scanner.nextLine().split("\\s+");

            String name = tokens[0];
            int age = Integer.parseInt(tokens[1]);

            treeSet.add(new Person(name, age));
            hashSet.add(new Person(name, age));
        }

        System.out.println(treeSet.size());
        System.out.println(hashSet.size());
    }
}