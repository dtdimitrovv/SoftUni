package com.company;

import java.util.*;
import java.util.stream.Collectors;

public class Main {

    public static void main(String[] args) throws Exception {
        Scanner scanner = new Scanner(System.in);

        List<Person> people = new ArrayList<>();

        String command;
        while (!"END".equals(command = scanner.nextLine())) {
            String[] tokens = command.split("\\s+");

            String name = tokens[0];
            int age = Integer.parseInt(tokens[1]);
            String city = tokens[2];

            people.add(new Person(name, age, city));
        }

        int n = Integer.parseInt(scanner.nextLine());

        Person personToCompare = people.get(n - 1); // n - 1 as we start counting from 0

        int numberOfEqualPeople = 0;
        int numberOfNotEqualPeople = 0;

        for (Person person : people) {
            if (person.compareTo(personToCompare) == 0) {
                numberOfEqualPeople++;
            } else {
                numberOfNotEqualPeople++;
            }
        }

        if (numberOfEqualPeople == 1) { // We already have one person when we enter their position in the list
            System.out.println("No matches");
        } else {
            System.out.printf("%d %d %d\n", numberOfEqualPeople, numberOfNotEqualPeople, people.size());
        }
    }
}