package com.company;

import java.util.*;
import java.util.stream.Collectors;

public class Main {

    public static void main(String[] args) throws Exception {
        Scanner scanner = new Scanner(System.in);

        Stack<Integer> stack = new Stack<>();

        String command;
        while (!"END".equals(command = scanner.nextLine())) {
            List<String> tokens = Arrays.stream(command.split("\\s+")).collect(Collectors.toList());

            if (tokens.get(0).equals("Push")) {
                for (int i = 1; i < tokens.size() - 1; i++) { // tokens.size() - 1 as we don't need to modify the element
                    // Remove the commas
                    String current = tokens.get(i);
                    tokens.set(i, current.substring(0, current.length() - 1));
                }

                for (int i = 1; i < tokens.size(); i++) {
                    stack.pushElement(Integer.parseInt(tokens.get(i)));
                }
            } else {
                stack.popElement();
            }
        }
        if (stack.getSize() != 0) {
            stack.iterator().forEachRemaining(System.out::println);
            stack.iterator().forEachRemaining(System.out::println);
        }
    }
}