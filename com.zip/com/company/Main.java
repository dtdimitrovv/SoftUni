package com.company;

import java.util.*;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String[] tokens = scanner.nextLine().split("\\s+");

        String name = String.format("%s %s", tokens[0], tokens[1]);
        String address = tokens[2];

        Tuple<String, String> tuple = new Tuple<>(name, address);

        System.out.println(tuple);

        //////////////////////////////////////////////////////////////////////

        tokens = scanner.nextLine().split("\\s+");

        name = tokens[0];
        int liters = Integer.parseInt(tokens[1]);

        Tuple<String,Integer>tuple2 = new Tuple<>(name, liters);

        System.out.println(tuple2);


        ////////////////////////////////////////////////////////////////////////////////

        tokens = scanner.nextLine().split("\\s+");

        int integer = Integer.parseInt(tokens[0]);
        Double doubleNum = Double.parseDouble(tokens[1]);

        Tuple<Integer,Double>tuple1 = new Tuple<>(integer,doubleNum);

        System.out.println(tuple1);
    }
}