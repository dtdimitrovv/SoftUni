package com.company;

import java.util.*;
import java.util.stream.Collectors;

public class Main {

    public static void main(String[] args) throws Exception {
        Scanner scanner = new Scanner(System.in);

        List<Integer> numbers = Arrays.stream(scanner.nextLine().split(",\\s+")).map(Integer::parseInt).collect(Collectors.toList());

        String end = scanner.nextLine();

        StringBuilder builder = new StringBuilder();

        Iterator<Integer> iterator = new ListIter(numbers, true);
        while (iterator.hasNext()) {
            String number = String.valueOf(iterator.next());
            if (!number.equals("null")) {
                builder.append(number).append(", ");
            }
        }

        iterator = new ListIter(numbers, false);
        while (iterator.hasNext()) {
            String number = String.valueOf(iterator.next());
            if (!number.equals("null")) {
                builder.append(number).append(", ");
            }
        }

        System.out.println(builder.substring(0, builder.length() - 2));
    }

    private static class ListIter implements Iterator<Integer> {
        private List<Integer> list;
        private boolean getEvenIndexes;
        private int index;

        public ListIter(List<Integer> list, boolean getEvenIndexes) {
            this.list = list;
            this.index = -1;
            this.getEvenIndexes = getEvenIndexes;
        }

        @Override
        public boolean hasNext() {
            return this.index < this.list.size() - 1;
        }

        @Override
        public Integer next() {
            this.index++;
            if (this.getEvenIndexes) {
                if (this.index % 2 == 0) {
                    return this.list.get(this.index);
                }
            } else {
                if (this.index % 2 != 0) {
                    return this.list.get(this.index);
                }
            }
            return null;
        }
    }
}