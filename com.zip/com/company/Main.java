package com.company;

import java.util.*;

public class Main {

    public static void main(String[] args) throws Exception {
        Scanner scanner = new Scanner(System.in);

        ListyIterator listyIterator = new ListyIterator();

        String command;
        while (!"END".equals(command = scanner.nextLine())) {

            String[] tokens = command.split("\\s+");

            if (tokens[0].equals("Create")) {
                listyIterator.create(tokens);
            } else if (tokens[0].equals("Move")) {
                System.out.println(listyIterator.Move());
            } else if (tokens[0].equals("Print")) {
                listyIterator.Print();
            } else if (tokens[0].equals("HasNext")) {
                System.out.println(listyIterator.HasNext());
            }
        }
    }
}