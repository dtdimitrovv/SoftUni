package com.company;

import java.util.*;
import java.util.stream.Collectors;

public class Main {

    public static void main(String[] args) throws Exception {
        Scanner scanner = new Scanner(System.in);

        Comparator<Person> nameComparator = new NameComparator();
        Comparator<Person> ageComparator = new AgeComparator();

        TreeSet<Person> setByName = new TreeSet<>(nameComparator);
        TreeSet<Person> setByAge = new TreeSet<>(ageComparator);

        int n = Integer.parseInt(scanner.nextLine());

        while (n-- > 0) {
            String[] tokens = scanner.nextLine().split("\\s+");

            String name = tokens[0];
            int age = Integer.parseInt(tokens[1]);

            setByName.add(new Person(name, age));
            setByAge.add(new Person(name, age));
        }

        for (Person person : setByName) {
            System.out.println(person.getName() + " " + person.getAge());
        }

        for (Person person : setByAge) {
            System.out.println(person.getName() + " " + person.getAge());
        }
    }
}