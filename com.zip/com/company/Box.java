package com.company;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Box<E extends Comparable<E>> {
    private List<E> items;

    public Box() {
        this.items = new ArrayList<>();
    }

    public void add(E item) {
        this.items.add(item);
    }

    public E remove(int index) {
        return this.items.remove(index);
    }

    public void swap(int index1, int index2) {
        E element1 = this.items.get(index1);
        E element2 = this.items.get(index2);

        this.items.set(index1, element2);
        this.items.set(index2, element1);
    }

    public boolean contains(E element) {
        return this.items.contains(element);
    }

    public int countGreaterThan(E itemToCompare) {
        int count = 0;

        for (E item : items) {
            if (item.compareTo(itemToCompare) > 0) {
                count++;
            }
        }

        return count;
    }

    public E getMin() {

        if (this.items.isEmpty()) {
            throw new IllegalArgumentException();
        }

        E minElement = this.items.get(0);

        for (E currentElement : this.items) {
            if (minElement.compareTo(currentElement) > 0) {
                minElement = currentElement;
            }
        }

        return minElement;
    }

    public E getMax() {

        if (this.items.isEmpty()) {
            throw new IllegalArgumentException();
        }

        E maxElement = this.items.get(0);

        for (E currentElement : this.items) {
            if (maxElement.compareTo(currentElement) < 0) {
                maxElement = currentElement;
            }
        }

        return maxElement;
    }

    public void sort() {
        Collections.sort(this.items);
    }

    @Override
    public String toString() {
        StringBuilder output = new StringBuilder();

        items.forEach(item -> output.append(String.format("%s%n", item)));

        return output.toString();
    }

    private String getClazz(E item) {
        return item.getClass().getCanonicalName();
    }
}
