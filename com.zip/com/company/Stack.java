package com.company;

import java.util.ArrayDeque;
import java.util.Iterator;

public class Stack<Integer> implements Iterable<Integer> {

    private static class Node<Integer> {
        private int element;
        private Node<Integer> previous;

        public Node(int element, Node<Integer> previous) {
            this.element = element;
            this.previous = previous;
        }

        public int getElement() {
            return element;
        }

        public void setElement(int element) {
            this.element = element;
        }

        public Node<Integer> getPrevious() {
            return previous;
        }

        public void setPrevious(Node<Integer> previous) {
            this.previous = previous;
        }
    }

    private Node<Integer> top = null;
    private int size = 0;

    public void pushElement(int value) {
        Node<Integer> newNode = new Node<>(value, null);

        // If the top is null we won't be able to work with it
        if (top != null) {
            newNode.setPrevious(this.top);
            this.top = newNode;
        } else {
            this.top = newNode;
        }

        this.size++;
    }

    public void popElement() {
        if (this.size == 0) {
            System.out.println("No elements");
        } else {
            this.top = this.top.getPrevious();
            this.size--;
        }
    }

    public int getSize() {
        return this.size;
    }

    @Override
    public Iterator<Integer> iterator() {
        return new Iterator<Integer>() {
            private Node<Integer> currentNode = top;

            @Override
            public boolean hasNext() {
                return currentNode != null;
            }

            @Override
            public Integer next() {
                int currentValue = currentNode.getElement();
                currentNode = currentNode.getPrevious();
                return (Integer)java.lang.Integer.valueOf(currentValue);
            }
        };
    }
}
