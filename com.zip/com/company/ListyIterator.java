package com.company;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ListyIterator {

    private int index;
    private List<String> items;

    public void create(String... items) {
        this.index = 0;
        this.items = new ArrayList<>();
        for (int i = 1; i < items.length; i++) {
            this.items.add(items[i]);
        }
    }

    // move an internal index position to the next index in the list,
    // the method should return true if it successfully moved and false if there is no next index.
    public boolean Move() {
        if (this.index + 1 < this.items.size()) {
            this.index++;
            return true;
        }
        return false;
    }

    public boolean HasNext() {
        return this.index < this.items.size() - 1;
    }

    public void Print() {
        try {
            System.out.println(this.items.get(index));
        } catch (Exception e) {
            System.out.println("Invalid Operation!");
        }
    }

    public void PrintAll() {
        Iterator<String> listIterator = new ListIterator(this.items);
        while (listIterator.hasNext()) {
            System.out.print(listIterator.next() + " ");
        }
        System.out.println(listIterator.next() + " ");
    }

    private static class ListIterator implements Iterator<String> {

        private int i;
        private List<String> list;

        private ListIterator(List<String> list) {
            this.list = list;
            this.i = 0;
        }

        @Override
        public boolean hasNext() {
            return this.i < this.list.size() - 1;
        }

        @Override
        public String next() {
            return this.list.get(i++);
        }
    }
}
