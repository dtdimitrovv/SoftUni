package com.company;

import java.util.ArrayList;
import java.util.List;

public class ListyIterator {

    private int index;
    private List<String> items;

    public void create(String... items) {
        this.index = 0;
        this.items = new ArrayList<>();
        for (int i = 1; i < items.length; i++) {
            this.items.add(items[i]);
        }
    }

    // move an internal index position to the next index in the list,
    // the method should return true if it successfully moved and false if there is no next index.
    public boolean Move() {
        if (this.index + 1 < this.items.size()) {
            this.index++;
            return true;
        }
        return false;
    }

    public boolean HasNext() {
        return this.index < this.items.size() - 1;
    }

    public void Print() {
        try {
            System.out.println(this.items.get(index));
        } catch (Exception e) {
            System.out.println("Invalid Operation!");
        }
    }
}
