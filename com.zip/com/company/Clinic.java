package com.company;

import java.util.ArrayList;
import java.util.List;

public class Clinic {
    private String name;
    List<Pet> pets; // Each pet will represent one room as in fact there will be only one pet in each room

    public Clinic(String name, int rooms) {
        this.name = name;
        this.pets = new ArrayList<>();
        for (int i = 0; i < rooms; i++) {
            this.pets.add(new Pet("", 0, ""));
        }
    }

    public String getName() {
        return name;
    }

    public boolean Add(Pet petToAdd) {

        int middleIndex = this.pets.size() / 2;
        int currentIndex = 1;

        if (isEmpty(this.pets.get(middleIndex))) {
            this.pets.set(middleIndex, petToAdd);
            return true;
        }

        while (middleIndex - currentIndex >= 0) {
            if (isEmpty(this.pets.get(middleIndex - currentIndex))) {
                this.pets.set(middleIndex - currentIndex, petToAdd);
                return true;
            } else if (isEmpty(this.pets.get(middleIndex + currentIndex))) {
                this.pets.set(middleIndex + currentIndex, petToAdd);
                return true;
            }
            currentIndex++;
        }
        return false;
    }

    public boolean ReleasePet() {

        int middleIndex = this.pets.size() / 2;

        for (int i = middleIndex; i < this.pets.size(); i++) {
            if (!isEmpty(this.pets.get(i))) {
                this.pets.set(i, new Pet("", 0, ""));
                return true;
            }
        }

        for (int i = 0; i < middleIndex; i++) {
            if (!isEmpty(this.pets.get(i))) {
                this.pets.set(i, new Pet("", 0, ""));
                return true;
            }
        }
        return false;
    }

    private boolean isEmpty(Pet pet) {
        if (pet.getName().equals("") && pet.getAge() == 0 && pet.getKind().equals("")) {
            return true;
        }
        return false;
    }

    public boolean HasEmptyRooms() {
        for (Pet pet : this.pets) {
            if (isEmpty(pet)) {
                return true;
            }
        }
        return false;
    }

    public void Print() {
        for (Pet pet : this.pets) {
            if (!isEmpty(pet)) {
                System.out.printf("%s %d %s\n", pet.getName(), pet.getAge(), pet.getKind());
            } else {
                System.out.println("Room empty");
            }
        }
    }

    public void PrintRoom(int index) {
        if (!isEmpty(this.pets.get(index))) {
            System.out.printf("%s %d %s\n", this.pets.get(index).getName(), this.pets.get(index).getAge(), this.pets.get(index).getKind());
        } else {
            System.out.println("Room empty");
        }
    }
}
