package com.company;

public class Person implements Comparable<Person> {
    private String name;
    private int age;
    private String city;

    public Person(String name, int age, String city) {
        this.name = name;
        this.age = age;
        this.city = city;
    }

    @Override
    public int compareTo(Person other) {
        if (this.name.equals(other.name) && this.age == other.age && this.city.equals(other.city)) {
            return 0;
        }
        return 1;
    }
}
