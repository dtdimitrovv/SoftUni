package Vehicles;

public class Truck extends Vehicle {
    public Truck(double fuelQuantity, double fuelConsumption, double tankCapacity) {
        super("Truck", fuelQuantity, fuelConsumption, tankCapacity);
        super.setFuelConsumption(super.getFuelConsumption() + 1.6);
    }

    @Override
    public void refuel(double litres) {
        super.refuel(litres * 0.95);
    }
}
