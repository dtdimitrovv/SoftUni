package Vehicles;

import java.text.DecimalFormat;
import java.text.NumberFormat;

public class Vehicle {
    private String type;
    private double fuelQuantity;
    private double fuelConsumption;
    private double tankCapacity;
    private NumberFormat format;

    public Vehicle(String type, double fuelQuantity, double fuelConsumption, double tankCapacity) {
        this.setType(type);
        this.setFuelQuantity(fuelQuantity);
        this.setFuelConsumption(fuelConsumption);
        this.setTankCapacity(tankCapacity);
        this.format = new DecimalFormat("#.##");
        format.setMinimumFractionDigits(0);
    }

    public void setTankCapacity(double tankCapacity) {
        this.tankCapacity = tankCapacity;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setFuelConsumption(double fuelConsumption) {
        this.fuelConsumption = fuelConsumption;
    }

    public void setFuelQuantity(double fuelQuantity) {
        if (fuelQuantity <= 0) {
            System.out.println("Fuel must be a positive number");
        } else {
            this.fuelQuantity = fuelQuantity;
        }
    }

    public double getFuelQuantity() {
        return fuelQuantity;
    }

    public double getFuelConsumption() {
        return fuelConsumption;
    }

    public void drive(double distance) {
        double leftFuelAfterTravelling = this.fuelQuantity - distance * this.fuelConsumption;

        if (leftFuelAfterTravelling >= 0) {
            System.out.printf("%s travelled %s km\n", this.type, format.format(distance));
            this.setFuelQuantity(leftFuelAfterTravelling);
        } else {
            System.out.printf("%s needs refueling\n", this.type);
        }
    }

    public double getTankCapacity() {
        return tankCapacity;
    }

    public String getType() {
        return type;
    }

    public NumberFormat getFormat() {
        return format;
    }

    public void refuel(double litres) {
        if (litres <= 0) {
            System.out.println("Fuel must be a positive number");
        } else if (litres + this.fuelQuantity > this.tankCapacity) {
            System.out.println("Cannot fit fuel in tank");
        } else {
            this.setFuelQuantity(this.getFuelQuantity() + litres);
        }
    }
}
