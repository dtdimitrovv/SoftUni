package Vehicles;

public class Bus extends Vehicle {
    public Bus(double fuelQuantity, double fuelConsumption, double tankCapacity) {
        super("Bus", fuelQuantity, fuelConsumption, tankCapacity);
    }

    @Override
    public void drive(double distance) {
        double leftFuelAfterTravelling = super.getFuelQuantity() - distance * (super.getFuelConsumption() + 1.4);

        if (leftFuelAfterTravelling >= 0) {
            System.out.printf("%s travelled %s km\n", super.getType(), getFormat().format(distance));
            this.setFuelQuantity(leftFuelAfterTravelling);
        } else {
            System.out.printf("%s needs refueling\n", super.getType());
        }
    }

    public void driveEmpty(double distance) {
        double leftFuelAfterTravelling = super.getFuelQuantity() - distance * super.getFuelConsumption();

        if (leftFuelAfterTravelling >= 0) {
            System.out.printf("%s travelled %s km\n", super.getType(), getFormat().format(distance));
            this.setFuelQuantity(leftFuelAfterTravelling);
        } else {
            System.out.printf("%s needs refueling\n", super.getType());
        }
    }
}
