package Pizza;

public class Topping {
    private enum toppingModifiers {
        MEAT(1.2),
        VEGGIES(0.8),
        CHEESE(1.1),
        SAUCE(0.9);

        private final double calories;

        toppingModifiers(double calories) {
            this.calories = calories;
        }

        public double getCalories() {
            return calories;
        }
    }

    private String toppingType;
    private double weight;

    public Topping(String toppingType, double weight) {
        this.setToppingType(toppingType);
        this.setWeight(weight);
    }

    private void setToppingType(String toppingType) {
        if (toppingType.equalsIgnoreCase("MEAT")
                || toppingType.equalsIgnoreCase("VEGGIES")
                || toppingType.equalsIgnoreCase("CHEESE")
                || toppingType.equalsIgnoreCase("SAUCE")) {
            this.toppingType = toppingType;
        } else {
            throw new IllegalArgumentException("Cannot place " + toppingType + " on top of your pizza.");
        }
    }

    private void setWeight(double weight) {
        if (weight < 1 || weight > 50) {
            throw new IllegalArgumentException(this.toppingType + " weight should be in the range [1..50].");
        }
        this.weight = weight;
    }

    public double calculateCalories() {
        return 2 * this.weight * toppingModifiers.valueOf(this.toppingType.toUpperCase()).getCalories();
    }
}
