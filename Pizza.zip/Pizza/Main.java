package Pizza;

import input.Reader;

public class Main {
    public static void main(String[] args) {
        try {
            String[] pizzaInput = Reader.readStringArray("\\s+");

            Pizza pizza = new Pizza(pizzaInput[1], Integer.parseInt(pizzaInput[2]));

            String[] doughInput = Reader.readStringArray("\\s+");

            Dough dough = new Dough(doughInput[1], doughInput[2], Double.parseDouble(doughInput[3]));

            pizza.setDough(dough);

            String command;
            while (!"END".equals(command = Reader.readString())) {
                String[] currentToppingInput = command.split("\\s+");

                Topping newTopping = new Topping(currentToppingInput[1], Double.parseDouble(currentToppingInput[2]));

                pizza.addTopping(newTopping);
            }

            System.out.printf("%s - %.2f", pizza.getName(), pizza.getOverallCalories());
        } catch (IllegalArgumentException exception) {
            System.out.println(exception.getMessage());
            return;
        }
    }
}
