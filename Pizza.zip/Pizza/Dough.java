package Pizza;

public class Dough {

    private enum doughModifiers {
        WHITE(1.5),
        WHOLEGRAIN(1),
        CRISPY(0.9),
        CHEWY(1.1),
        HOMEMADE(1);

        private final double calories;

        doughModifiers(double calories) {
            this.calories = calories;
        }

        public double getCalories() {
            return calories;
        }
    }

    private String flourType;
    private String bakingTechnique;
    private double weight;

    public Dough(String flourType, String bakingTechnique, double weight) {
        this.setFlourType(flourType);
        this.setBakingTechnique(bakingTechnique);
        this.setWeight(weight);
    }

    private void setFlourType(String flourType) {
        if (flourType.equalsIgnoreCase("WHITE") || flourType.equalsIgnoreCase("WHOLEGRAIN")) {
            this.flourType = flourType;
        } else {
            throw new IllegalArgumentException("Invalid type of dough.");
        }
    }

    private void setBakingTechnique(String bakingTechnique) {
        if (bakingTechnique.equalsIgnoreCase("CRISPY")
                || bakingTechnique.equalsIgnoreCase("CHEWY")
                || bakingTechnique.equalsIgnoreCase("HOMEMADE")) {
            this.bakingTechnique = bakingTechnique;
        } else {
            throw new IllegalArgumentException("Invalid type of dough.");
        }
    }

    private void setWeight(double weight) {
        if (weight < 1 || weight > 200) {
            throw new IllegalArgumentException("Dough weight should be in the range [1..200].");
        }
        this.weight = weight;
    }

    public double calculateCalories() {
        return this.weight * 2
                * doughModifiers.valueOf(this.flourType.toUpperCase()).getCalories()
                * doughModifiers.valueOf(this.bakingTechnique.toUpperCase()).getCalories();
    }
}
