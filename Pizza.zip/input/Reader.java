package input;

import java.util.Arrays;
import java.util.Scanner;

public class Reader {

    public static Scanner scanner = new Scanner(System.in);

    public static int[] readIntArray(String delimiter){
        return Arrays.stream(scanner.nextLine().split(delimiter))
                .mapToInt(Integer::parseInt)
                .toArray();
    }

    public static double[] readDoubleArray(String delimiter){
        return Arrays.stream(scanner.nextLine().split(delimiter))
                .mapToDouble(Double::parseDouble)
                .toArray();
    }

    public static String[] readStringArray(String delimiter){
        return scanner.nextLine().split(delimiter);
    }

    public static String readString(){
        return scanner.nextLine();
    }

    public static int readInt(){
        return Integer.parseInt(scanner.nextLine());
    }
}
