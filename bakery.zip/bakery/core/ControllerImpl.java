package bakery.core;

import bakery.core.interfaces.Controller;
import bakery.entities.bakedFoods.interfaces.BakedFood;
import bakery.entities.bakedFoods.interfaces.BaseFood;
import bakery.entities.bakedFoods.interfaces.Bread;
import bakery.entities.bakedFoods.interfaces.Cake;
import bakery.entities.drinks.interfaces.BaseDrink;
import bakery.entities.drinks.interfaces.Drink;
import bakery.entities.drinks.interfaces.Tea;
import bakery.entities.drinks.interfaces.Water;
import bakery.entities.tables.interfaces.BaseTable;
import bakery.entities.tables.interfaces.InsideTable;
import bakery.entities.tables.interfaces.OutsideTable;
import bakery.entities.tables.interfaces.Table;
import bakery.repositories.interfaces.*;

import static bakery.common.ExceptionMessages.*;
import static bakery.common.OutputMessages.*;

public class ControllerImpl implements Controller {
    private FoodRepositoryImpl foodRepository;
    private DrinkRepositoryImpl drinkRepository;
    private TableRepositoryImpl tableRepository;
    private double totalIncome;

    public ControllerImpl(FoodRepository<BakedFood> foodRepository, DrinkRepository<Drink> drinkRepository, TableRepository<Table> tableRepository) {
        this.foodRepository = new FoodRepositoryImpl();
        this.drinkRepository = new DrinkRepositoryImpl();
        this.tableRepository = new TableRepositoryImpl();
    }

    @Override
    public String addFood(String type, String name, double price) {
        for (BaseFood baseFood : foodRepository.getAll()) {
            if (baseFood.getName().equals(name)) {
                throw new IllegalArgumentException(String.format("%s %s is already in the menu", type, name));
            }
        }
        BaseFood food = null;
        if (type.equals("Bread")) {
            food = new Bread(name, price);
        } else if (type.equals("Cake")) {
            food = new Cake(name, price);
        }
        this.foodRepository.add(food);
        return String.format(FOOD_ADDED, name, type);
    }

    @Override
    public String addDrink(String type, String name, int portion, String brand) {
        for (BaseDrink drink : this.drinkRepository.getAll()) {
            if (drink.getName().equals(name)) {
                throw new IllegalArgumentException(String.format("%s %s is already in the menu", type, name));
            }
        }
        BaseDrink drink = null;
        if (type.equals("Tea")) {
            drink = new Tea(name, portion, brand);
        } else if (type.equals("Water")) {
            drink = new Water(name, portion, brand);
        }
        this.drinkRepository.add(drink);
        return String.format(DRINK_ADDED, name, brand);
    }

    @Override
    public String addTable(String type, int tableNumber, int capacity) {
        for (BaseTable table : this.tableRepository.getAll()) {
            if (table.getTableNumber() == tableNumber) {
                throw new IllegalArgumentException(String.format(TABLE_EXIST, tableNumber));
            }
        }
        BaseTable table = null;
        if (type.equals("InsideTable")) {
            table = new InsideTable(tableNumber, capacity);
        } else if (type.equals("OutsideTable")) {
            table = new OutsideTable(tableNumber, capacity);
        }
        this.tableRepository.add(table);
        return String.format(TABLE_ADDED, tableNumber);
    }

    @Override
    public String reserveTable(int numberOfPeople) {
        for (BaseTable table : this.tableRepository.getAll()) {
            if (table.getCapacity() >= numberOfPeople && !table.isReserved()) {
                table.reserve(numberOfPeople);
                return String.format(TABLE_RESERVED, table.getTableNumber(), numberOfPeople);
            }
        }

        return String.format(RESERVATION_NOT_POSSIBLE, numberOfPeople);
    }

    @Override
    public String orderFood(int tableNumber, String foodName) {
        for (BaseTable table : this.tableRepository.getAll()) {
            if (table.getTableNumber() == tableNumber && table.isReserved()) {
                for (BaseFood food : this.foodRepository.getAll()) {
                    if (food.getName().equals(foodName)) {
                        table.orderFood(food);
                        return String.format(FOOD_ORDER_SUCCESSFUL, tableNumber, foodName);
                    }
                }
                return String.format(NONE_EXISTENT_FOOD, foodName);
            }
        }
        return String.format(WRONG_TABLE_NUMBER, tableNumber);
    }

    @Override
    public String orderDrink(int tableNumber, String drinkName, String drinkBrand) {
        for (BaseTable table : this.tableRepository.getAll()) {
            if (table.getTableNumber() == tableNumber) {
                for (BaseDrink drink : this.drinkRepository.getAll()) {
                    if (drink.getName().equals(drinkName) && drink.getBrand().equals(drinkBrand)) {
                        table.orderDrink(drink);
                        return String.format(DRINK_ORDER_SUCCESSFUL, tableNumber, drinkName, drinkBrand);
                    }
                }
                return String.format(NON_EXISTENT_DRINK, drinkName, drinkBrand);
            }
        }
        return String.format(WRONG_TABLE_NUMBER, tableNumber);
    }

    @Override
    public String leaveTable(int tableNumber) {
        for (BaseTable table : this.tableRepository.getAll()) {
            if (table.getTableNumber() == tableNumber) {
                double tableBill = table.getBill();

                this.totalIncome += tableBill;

                table.clear();
                return String.format("Table: %d\nBill: %.2f", table.getTableNumber(), tableBill);
            }
        }
        return null;
    }

    @Override
    public String getFreeTablesInfo() {
        StringBuilder output = new StringBuilder();

        for (BaseTable table : this.tableRepository.getAll()) {
            if (!table.isReserved()) {
                output.append(table.getFreeTableInfo()).append(System.lineSeparator());
            }
        }

        return output.toString().trim();
    }

    @Override
    public String getTotalIncome() {
        return String.format("Total income: %.2flv", this.totalIncome);
    }
}
