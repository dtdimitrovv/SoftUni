package bakery.repositories.interfaces;

import bakery.entities.tables.interfaces.BaseTable;

import java.util.ArrayList;
import java.util.List;

public class TableRepositoryImpl implements TableRepository {
    private List<BaseTable> tables;

    public TableRepositoryImpl() {
        this.tables = new ArrayList<>();
    }

    @Override
    public List<BaseTable> getAll() {
        return this.tables;
    }

    @Override
    public void add(Object o) {
        this.tables.add((BaseTable) o);
    }

    @Override
    public Object getByNumber(int number) {
        return this.tables.stream().filter(e -> e.getTableNumber() == number);
    }
}
