package bakery.repositories.interfaces;

import bakery.entities.bakedFoods.interfaces.BaseFood;

import java.util.ArrayList;
import java.util.List;

public class FoodRepositoryImpl implements FoodRepository {
    private List<BaseFood> food;

    public FoodRepositoryImpl() {
        this.food = new ArrayList<>();
    }

    @Override
    public Object getByName(String name) {
        return this.food.stream().filter(e -> e.getName().equals(name));
    }

    @Override
    public List<BaseFood> getAll() {
        return this.food;
    }

    @Override
    public void add(Object o) {
        this.food.add((BaseFood) o);
    }
}
