package bakery.repositories.interfaces;

import bakery.entities.drinks.interfaces.BaseDrink;

import java.util.ArrayList;
import java.util.List;

public class DrinkRepositoryImpl implements DrinkRepository {
    private List<BaseDrink> drinks;

    public DrinkRepositoryImpl() {
        this.drinks = new ArrayList<>();
    }

    @Override
    public Object getByNameAndBrand(String drinkName, String drinkBrand) {
        for (BaseDrink drink : this.drinks) {
            if (drink.getName().equals(drinkName) && drink.getBrand().equals(drinkBrand)) {
                return drink;
            }
        }
        return null;
    }

    @Override
    public List<BaseDrink> getAll() {
        return this.drinks;
    }

    @Override
    public void add(Object o) {
        this.drinks.add((BaseDrink) o);
    }
}
