package bakery.entities.bakedFoods.interfaces;

public class Cake extends BaseFood{
    public Cake(String name, double price) {
        super(name, 245, price);
    }
}
