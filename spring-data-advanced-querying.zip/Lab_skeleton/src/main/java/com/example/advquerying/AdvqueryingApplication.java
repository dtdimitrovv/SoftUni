package com.example.advquerying;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

 @SpringBootApplication
public class AdvqueryingApplication {

    public static void main(String[] args) {
         SpringApplication.run(AdvqueryingApplication.class, args);
    }

}
