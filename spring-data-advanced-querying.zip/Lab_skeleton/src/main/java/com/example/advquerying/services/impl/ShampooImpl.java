package com.example.advquerying.services.impl;

import com.example.advquerying.entities.Shampoo;
import com.example.advquerying.entities.Size;
import com.example.advquerying.repositories.ShampooRepository;
import com.example.advquerying.services.ShampooService;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Set;

@Service
public class ShampooImpl implements ShampooService {
    private final ShampooRepository shampooRepository;

    public ShampooImpl(ShampooRepository shampooRepository) {
        this.shampooRepository = shampooRepository;
    }

    @Override
    public List<Shampoo> getAllShampoosByGivenSize(Size size) {
        return this.shampooRepository.findDistinctBySize_OrderById(size);
    }

    @Override
    public List<Shampoo> getShampoosBySizeOrLabel(Size size, Long labelId) {
        return this.shampooRepository.findDistinctBySizeOrLabel_IdOrderByPrice(size, labelId);
    }

    @Override
    public List<Shampoo> getShampoosWithHigherPriceThanAGivenOne(BigDecimal inputPrice) {
        return this.shampooRepository.findDistinctByPriceGreaterThanOrderByPriceDesc(inputPrice);
    }

    @Override
    public List<String> getDistinctShampooBrandsWhereShampoosHaveGivenIngredients(Set<String> ingredientsNames) {
        return this.shampooRepository.findDistinctByIngredientsIn(ingredientsNames);
    }

    @Override
    public List<Shampoo> getShampoosByGivenIngredientsCountLessThanGivenCount(int count) {
        return this.shampooRepository.findDistinctByIngredientsCountLessThanGivenCount(count);
    }
}
