package com.example.advquerying.services;

public interface LabelService {
}
