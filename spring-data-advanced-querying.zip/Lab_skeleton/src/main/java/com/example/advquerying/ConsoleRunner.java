package com.example.advquerying;

import com.example.advquerying.entities.Ingredient;
import com.example.advquerying.entities.Shampoo;
import com.example.advquerying.entities.Size;
import com.example.advquerying.services.IngredientService;
import com.example.advquerying.services.LabelService;
import com.example.advquerying.services.ShampooService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.*;

@Component
public class ConsoleRunner implements CommandLineRunner {
    private final LabelService labelService;
    private final IngredientService ingredientService;
    private final ShampooService shampooService;
    private final Scanner scanner;

    public ConsoleRunner(LabelService labelService, IngredientService ingredientService, ShampooService shampooService) {
        this.labelService = labelService;
        this.ingredientService = ingredientService;
        this.shampooService = shampooService;
        this.scanner = new Scanner(System.in);
    }

    @Override
    public void run(String... args) throws Exception {
        
    }

    private void updateIngredientsPriceBy10Percent() {
        this.ingredientService.updatePriceBy10Percent();
    }

    private void deleteIngredientByGivenName() {
        String name = scanner.nextLine();
        this.ingredientService.deleteByGivenName(name);
    }

    private void printShampoosByGivenIngredientsCount() {
        int count = Integer.parseInt(scanner.nextLine());

        List<Shampoo> shampoos = this.shampooService.getShampoosByGivenIngredientsCountLessThanGivenCount(count);
        shampoos.forEach(s -> System.out.println(s.getBrand()));
    }

    private void printDistinctShampooBrandsWhereShampoosHaveGivenIngredients() {
        Set<String> ingredientsNames = new LinkedHashSet<>();
        String currentIngredientName = scanner.nextLine();
        while (!currentIngredientName.isBlank()) {
            ingredientsNames.add(currentIngredientName);
            currentIngredientName = scanner.nextLine();
        }

        List<String> shampoos = this.shampooService.getDistinctShampooBrandsWhereShampoosHaveGivenIngredients(ingredientsNames);
        shampoos.forEach(System.out::println);
    }

    private void printCountShampoosWithPriceLowerThanAGivenOne() {
        BigDecimal inputPrice = new BigDecimal(scanner.nextLine());
        System.out.println(this.ingredientService.countShampoosByPriceLowerThanAGivenOne(inputPrice));
    }

    private void printIngredientsByNameStartingWithAGivenLetter() {
        String startingLetters = scanner.nextLine();
        List<Ingredient> ingredientNames = this.ingredientService.getIngredientsByNameStartingWithAGivenLetter(startingLetters);
        ingredientNames.forEach(ingredient -> {
            System.out.println(ingredient.getName());
        });
    }

    private void printShampoosByGivenPrice() {
        BigDecimal inputPrice = new BigDecimal(scanner.nextLine());
        List<Shampoo> shampoos = this.shampooService.getShampoosWithHigherPriceThanAGivenOne(inputPrice);
        shampoos.forEach(shampoo -> {
            System.out.printf("%s %s %.2flv.\n", shampoo.getBrand(), shampoo.getSize(), shampoo.getPrice());
        });
    }

    private void printShampoosBySizeOrLabel() {
        String sizeInput = scanner.nextLine().toUpperCase();
        Size size = Size.valueOf(sizeInput);
        long labelId = Integer.parseInt(scanner.nextLine());
        List<Shampoo> shampoos = this.shampooService.getShampoosBySizeOrLabel(size, labelId);
        shampoos.forEach(shampoo -> {
            System.out.printf("%s %s %.2flv.\n", shampoo.getBrand(), shampoo.getSize(), shampoo.getPrice());
        });
    }

    private void printShampoosByInputSize() {
        String sizeInput = scanner.nextLine().toUpperCase();
        Size size = Size.valueOf(sizeInput);
        List<Shampoo> allShampoosByGivenSize = this.shampooService.getAllShampoosByGivenSize(size);
        allShampoosByGivenSize.forEach(shampoo -> {
            System.out.printf("%s %s %.2flv.\n", shampoo.getBrand(), shampoo.getSize(), shampoo.getPrice());
        });
    }
}
