package com.example.advquerying.services;

import com.example.advquerying.entities.Ingredient;

import java.math.BigDecimal;
import java.util.List;

public interface IngredientService {
    List<Ingredient> getIngredientsByNameStartingWithAGivenLetter(String letters);

    int countShampoosByPriceLowerThanAGivenOne(BigDecimal inputPrice);

    void deleteByGivenName(String name);

    void updatePriceBy10Percent();
}
