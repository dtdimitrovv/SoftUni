package com.example.advquerying.repositories;

import com.example.advquerying.entities.Shampoo;
import com.example.advquerying.entities.Size;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;
import java.util.Set;

@Repository
public interface ShampooRepository extends JpaRepository<Shampoo, Long> {
    List<Shampoo> findDistinctBySize_OrderById(Size size);

    List<Shampoo> findDistinctBySizeOrLabel_IdOrderByPrice(Size size, Long labelId);

    List<Shampoo> findDistinctByPriceGreaterThanOrderByPriceDesc(BigDecimal price);

    @Query("SELECT DISTINCT s.brand FROM Shampoo s JOIN s.ingredients i WHERE i.name in :ingredientsNames")
    List<String> findDistinctByIngredientsIn(@Param(value = "ingredientsNames") Set<String> ingredientsNames);

    @Query("SELECT DISTINCT s FROM Shampoo s WHERE s.ingredients.size < :count")
    List<Shampoo> findDistinctByIngredientsCountLessThanGivenCount(int count);
}
