package com.example.advquerying.services.impl;

import com.example.advquerying.services.LabelService;
import org.springframework.stereotype.Service;

@Service
public class LabelImpl implements LabelService {
}
