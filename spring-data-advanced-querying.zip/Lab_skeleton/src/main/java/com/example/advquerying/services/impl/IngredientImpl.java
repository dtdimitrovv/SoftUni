package com.example.advquerying.services.impl;

import com.example.advquerying.entities.Ingredient;
import com.example.advquerying.repositories.IngredientRepository;
import com.example.advquerying.services.IngredientService;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.math.BigDecimal;
import java.util.List;

@Service
public class IngredientImpl implements IngredientService {
    private final IngredientRepository ingredientRepository;

    public IngredientImpl(IngredientRepository ingredientRepository) {
        this.ingredientRepository = ingredientRepository;
    }

    @Override
    public List<Ingredient> getIngredientsByNameStartingWithAGivenLetter(String letters) {
        return this.ingredientRepository.findDistinctByNameStartingWith(letters);
    }

    @Override
    public int countShampoosByPriceLowerThanAGivenOne(BigDecimal inputPrice) {
        return this.ingredientRepository.countDistinctByPriceLessThan(inputPrice);
    }

    @Override
    @Transactional
    public void deleteByGivenName(String name) {
        this.ingredientRepository.deleteAllByName(name);
    }

    @Override
    @Transactional
    public void updatePriceBy10Percent() {
        this.ingredientRepository.updateBy10Percent();
    }
}
