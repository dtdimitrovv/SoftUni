package com.company;

import java.util.*;
import java.util.stream.Collectors;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Read the number of cars
        int n = Integer.parseInt(scanner.nextLine());

        // Store them in a list
        List<Car> cars = new ArrayList<>();

        // Fill in the list
        while (n-- > 0) {
            String[] tokens = scanner.nextLine().split("\\s+");

            String name = tokens[0];
            double fuelAmount = Double.parseDouble(tokens[1]);
            double fuelCostFor1km = Double.parseDouble(tokens[2]);

            cars.add(new Car(name, fuelAmount, fuelCostFor1km));
        }

        String command;
        while (!"End".equals(command = scanner.nextLine())) {
            checkDistance(cars, command);
        }

        for (Car car : cars) {
            System.out.println(car.toString());
        }
    }

    static void checkDistance(List<Car> cars, String command) {
        String[] tokens = command.split("\\s+"); // Split the command so we can use its info properly

        String currentModel = tokens[1];
        int distance = Integer.parseInt(tokens[2]);

        for (Car car : cars) {

            // Find the car
            if (car.getModel().equals(currentModel)) {

                // Check if we can travel the distance, if the fuel is sufficient
                if (car.getFuelAmount() - car.getFuelCostPerKilometer() * distance >= 0) {

                    // Decrease the available fuel
                    car.setFuelAmount(car.getFuelAmount() - car.getFuelCostPerKilometer() * distance);

                    // Increase the travelled distance
                    car.setTravelledDistance(car.getTravelledDistance() + distance);
                } else {
                    System.out.println("Insufficient fuel for the drive");
                }
            }
        }
    }
}