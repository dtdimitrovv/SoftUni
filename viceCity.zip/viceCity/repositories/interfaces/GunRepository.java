package viceCity.repositories.interfaces;

import viceCity.models.guns.Gun;

import java.util.ArrayList;
import java.util.List;

public class GunRepository implements Repository {
    private List<Gun> models;

    public GunRepository() {
        this.models = new ArrayList<>();
    }

    @Override
    public List<Gun> getModels() {
        return this.models;
    }

    @Override
    public void add(Object model) {
        this.models.add((Gun) model);
    }

    @Override
    public boolean remove(Object model) {
        return this.models.remove(model);
    }

    @Override
    public Object find(String name) {
        for (Gun model : this.models) {
            if (model.getName().equals(name)) {
                return model;
            }
        }
        return null;
    }
}
