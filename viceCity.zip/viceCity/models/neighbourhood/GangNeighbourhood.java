package viceCity.models.neighbourhood;

import viceCity.models.guns.Gun;
import viceCity.models.players.Player;

import java.util.List;

public class GangNeighbourhood implements Neighbourhood {
    private int killedPeopleByMainPlayer;
    private int initialMainPlayerHealth;

    public GangNeighbourhood() {
        this.killedPeopleByMainPlayer = 0;
    }

    public int getInitialMainPlayerHealth() {
        return initialMainPlayerHealth;
    }

    public int getKilledPeopleByMainPlayer() {
        return this.killedPeopleByMainPlayer;
    }

    @Override
    public void action(Player mainPlayer, List<Player> civilPlayers) {

        this.initialMainPlayerHealth = mainPlayer.getLifePoints();

        List<Gun> mainPlayerGuns = mainPlayer.getGunRepository().getModels();

        Gun mainPlayerGun;

        if (!mainPlayerGuns.isEmpty()) {
            mainPlayerGun = mainPlayerGuns.remove(0);
            for (int i = 0; i < civilPlayers.size(); ) {
                Player civilPlayer = civilPlayers.get(i);
                while (civilPlayer.isAlive()) {
                    civilPlayer.takeLifePoints(mainPlayerGun.fire());
                    if (!mainPlayerGun.canFire()) {
                        if (mainPlayerGuns.isEmpty()) {
                            break;
                        } else {
                            mainPlayerGun = mainPlayerGuns.remove(0);
                        }
                    }
                }
                if (!civilPlayer.isAlive()) {
                    this.killedPeopleByMainPlayer++;
                    civilPlayers.remove(civilPlayer);
                }
                if (!mainPlayerGun.canFire()) {
                    break;
                }
            }
        }

        for (Player civilPlayer : civilPlayers) {
            List<Gun> currentPlayerGuns = civilPlayer.getGunRepository().getModels();

            if (currentPlayerGuns.isEmpty()) {
                continue;
            }

            Gun currentGun = currentPlayerGuns.remove(0);

            while (mainPlayer.isAlive()) {
                mainPlayer.takeLifePoints(currentGun.fire());
                if (!currentGun.canFire()) {
                    if (currentPlayerGuns.isEmpty()) {
                        break;
                    } else {
                        currentGun = currentPlayerGuns.remove(0);
                    }
                }
            }
        }
    }
}
