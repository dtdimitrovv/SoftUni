package viceCity.models.guns;

public class Rifle extends BaseGun {
    public Rifle(String name) {
        super(name, 50, 500);
    }

    @Override
    public int fire() {
        if (this.bulletsPerBarrel - 5 <= 0) {
            this.totalBullets -= 50;
            this.bulletsPerBarrel = 50;
        }
        this.bulletsPerBarrel -= 5;
        return 5;
    }
}
