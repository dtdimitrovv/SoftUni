package viceCity.core.interfaces;

import viceCity.models.guns.Gun;
import viceCity.models.guns.Pistol;
import viceCity.models.guns.Rifle;
import viceCity.models.neighbourhood.GangNeighbourhood;
import viceCity.models.players.CivilPlayer;
import viceCity.models.players.MainPlayer;
import viceCity.models.players.Player;

import java.util.ArrayList;
import java.util.List;

import static viceCity.common.ConstantMessages.*;

public class ControllerImpl implements Controller {
    private MainPlayer mainPlayer;
    private List<Player> civilPlayers;
    private List<Gun> guns;

    public ControllerImpl() {
        this.mainPlayer = new MainPlayer();
        this.civilPlayers = new ArrayList<>();
        this.guns = new ArrayList<>();
    }

    @Override
    public String addPlayer(String name) {
        this.civilPlayers.add(new CivilPlayer(name));
        return String.format(PLAYER_ADDED, name);
    }

    @Override
    public String addGun(String type, String name) {
        Gun gun;
        if (type.equals("Pistol")) {
            gun = new Pistol(name);
        } else if (type.equals("Rifle")) {
            gun = new Rifle(name);
        } else {
            return GUN_TYPE_INVALID;
        }

        this.guns.add(gun);

        return String.format(GUN_ADDED, name, type);
    }

    @Override
    public String addGunToPlayer(String name) {
        if (this.guns.isEmpty()) {
            return GUN_QUEUE_IS_EMPTY;
        }


        if (name.equals("Vercetti")) {
            Gun gun = this.guns.remove(0);
            this.mainPlayer.getGunRepository().add(gun);
            return String.format(GUN_ADDED_TO_MAIN_PLAYER, gun.getName(), this.mainPlayer.getName());
        }

        for (Player civilPlayer : this.civilPlayers) {
            if (civilPlayer.getName().equals(name)) {
                Gun gun = this.guns.remove(0);
                civilPlayer.getGunRepository().add(gun);
                return String.format(GUN_ADDED_TO_CIVIL_PLAYER, gun.getName(), civilPlayer.getName());
            }
        }

        return CIVIL_PLAYER_DOES_NOT_EXIST;
    }

    @Override
    public String fight() {
        GangNeighbourhood gangNeighbourhood = new GangNeighbourhood();

        gangNeighbourhood.action(this.mainPlayer, this.civilPlayers);

        if (gangNeighbourhood.getInitialMainPlayerHealth() == this.mainPlayer.getLifePoints()
                && gangNeighbourhood.getKilledPeopleByMainPlayer() == 0) {
            return FIGHT_HOT_HAPPENED;
        }

        String output = FIGHT_HAPPENED + "\n" +
                String.format(MAIN_PLAYER_LIVE_POINTS_MESSAGE, mainPlayer.getLifePoints()) + "\n" +
                String.format(MAIN_PLAYER_KILLED_CIVIL_PLAYERS_MESSAGE, gangNeighbourhood.getKilledPeopleByMainPlayer()) + "\n" +
                String.format(CIVIL_PLAYERS_LEFT_MESSAGE, this.civilPlayers.size());
        return output;
    }
}
