package university;

import java.util.ArrayList;
import java.util.List;

public class University {
    public int capacity;
    public List<Student> students;

    public University(int capacity) {
        this.capacity = capacity;
        this.students = new ArrayList<>();
    }

    public int getCapacity() {
        return capacity;
    }

    public List<Student> getStudents() {
        return students;
    }

    public int getStudentCount() {
        return this.students.size();
    }

    public String registerStudent(Student student) {

        if (this.students.size() == capacity) {
            return "No seats in the university";
        }

        for (Student currentStudent : this.students) {
            if (currentStudent.equals(student)) {
                return "Student is already in the university";
            }
        }

        this.students.add(student);

        return String.format("Added student %s %s", student.firstName, student.lastName);
    }

    public String dismissStudent(Student student) {
        for (Student currentStudent : this.students) {
            if (currentStudent.equals(student)) {
                this.students.remove(student);
                return String.format("Removed student %s %s", student.getFirstName(), student.getLastName());
            }
        }
        return "Student not found";
    }

    public Student getStudent(String firstName, String lastName) {
        for (Student currentStudent : this.students) {
            if (currentStudent.firstName.equals(firstName) && currentStudent.lastName.equals(lastName)) {
                return currentStudent;
            }
        }
        return null;
    }

    public String getStatistics() {
        StringBuilder builder = new StringBuilder();

        List<Student> studentList = this.students;
        for (int i = 0; i < studentList.size(); i++) {
            Student currentStudent = studentList.get(i);
            if (i == studentList.size() - 1) {
                builder.append(String.format("==Student: First Name = %s, Last Name = %s, Best Subject = %s",
                        currentStudent.getFirstName(), currentStudent.getLastName(), currentStudent.getBestSubject()));
            } else {
                builder.append(String.format("==Student: First Name = %s, Last Name = %s, Best Subject = %s\n",
                        currentStudent.getFirstName(), currentStudent.getLastName(), currentStudent.getBestSubject()));
            }
        }

        return builder.toString();
    }
}
