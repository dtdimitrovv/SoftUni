package FootballTeam;

import Input.Reader;

public class Main {
    public static void main(String[] args) {

        Teams teams = new Teams();

        String command;

        while (!"END".equals(command = Reader.readString())) {
            String[] tokens = command.split(";");

            if (tokens[0].equals("Team")) {
                teams.addTeam(tokens[1]);
            } else if (tokens[0].equals("Add")) {
                try {
                    String teamName = tokens[1];
                    String playerName = tokens[2];
                    int endurance = Integer.parseInt(tokens[3]);
                    int sprint = Integer.parseInt(tokens[4]);
                    int dribble = Integer.parseInt(tokens[5]);
                    int passing = Integer.parseInt(tokens[6]);
                    int shooting = Integer.parseInt(tokens[7]);

                    teams.addPlayer(teamName, playerName, endurance, sprint, dribble, passing, shooting);

                } catch (IllegalArgumentException exception) {
                    System.out.println(exception.getMessage());
                }

            } else if (tokens[0].equals("Remove")) {
                try {
                    String teamName = tokens[1];
                    String playerName = tokens[2];
                    teams.removePlayer(teamName, playerName);
                } catch (IllegalArgumentException exception) {
                    System.out.println(exception.getMessage());
                }
            } else if (tokens[0].equals("Rating")) {
                try {
                    String teamName = tokens[1];
                    System.out.println(teamName + " - " + teams.getRatingForATeam(teamName));
                } catch (IllegalArgumentException exception) {
                    System.out.println(exception.getMessage());
                }
            }
        }
    }
}
