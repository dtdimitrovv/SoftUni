package FootballTeam;

import java.util.ArrayList;
import java.util.List;

public class Teams {
    private List<Team> teams;

    public Teams() {
        this.teams = new ArrayList<>();
    }

    public void addTeam(String teamName) {
        this.teams.add(new Team(teamName));
    }

    public void addPlayer(String teamName, String playerName, int endurance, int sprint, int dribble, int passing, int shooting) {
        int teamIndex = teamIndex(teamName);
        if (teamIndex != -1) {
            this.teams.get(teamIndex).addPlayer(new Player(playerName, endurance, sprint, dribble, passing, shooting));
        } else {
            throw new IllegalArgumentException("Team " + teamName + " does not exist.");
        }
    }

    public void removePlayer(String teamName, String playerName) {
        int teamIndex = teamIndex(teamName);

        boolean playerIsPresentInTheTeam = false;

        for (Player player : this.teams.get(teamIndex).getPlayers()) {
            if (player.getName().equals(playerName)) {
                this.teams.get(teamIndex).getPlayers().remove(player);
                playerIsPresentInTheTeam = true;
                break;
            }
        }
        if (!playerIsPresentInTheTeam) {
            throw new IllegalArgumentException("Player " + playerName + " is not in " + teamName + " team.");
        }
    }

    public long getRatingForATeam(String teamName) {
        int teamIndex = teamIndex(teamName);
        if (teamIndex != -1) {
            return Math.round(this.teams.get(teamIndex).getRating());
        } else {
            throw new IllegalArgumentException("Team " + teamName + " does not exist.");
        }
    }

    private int teamIndex(String teamName) {
        for (int i = 0; i < this.teams.size(); i++) {
            Team team = this.teams.get(i);
            if (team.getName().equals(teamName)) {
                return i;
            }
        }
        return -1;
    }

}
