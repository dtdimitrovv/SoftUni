package Input;

public class ConsolePrinter {
    public static void printLine(String s){
        System.out.println(s);
    }

}
