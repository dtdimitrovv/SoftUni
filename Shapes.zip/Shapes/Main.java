package Shapes;

public class Main {
    public static void main(String[] args) {
        Shape circle = new Circle(4.0);
        Shape rect = new Rectangle(4.0, 5.0);

        System.out.println(circle.calculateArea());
        System.out.println(circle.calculatePerimeter());

        System.out.println(rect.calculateArea());
        System.out.println(rect.calculatePerimeter());
    }
}
