package aquarium;

import org.junit.Assert;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Collection;

public class AquariumTests {

    @Test
    public void testGetName() {
        Aquarium aquarium = new Aquarium("Ivan", 2);
        Assert.assertEquals("Ivan", aquarium.getName());
    }

    @Test
    public void testGetCapacity() {
        Aquarium aquarium = new Aquarium("Ivan", 2);
        aquarium.add(new Fish("1"));
        aquarium.add(new Fish("2"));
        Assert.assertEquals(2, aquarium.getCapacity());
    }

    @Test
    public void testFishSize() {
        Aquarium aquarium = new Aquarium("Ivan", 2);
        aquarium.add(new Fish("1"));
        aquarium.add(new Fish("2"));
        Assert.assertEquals(2, aquarium.getCount());
    }

    @Test(expected = NullPointerException.class)
    public void testSetNameShouldFailWhenNameIsNull() {
        new Aquarium(null, 10);
    }

    @Test(expected = NullPointerException.class)
    public void testSetNameShouldFailWhenNameIsWhiteSpaces() {
        new Aquarium("           ", 10);
    }

    @Test
    public void testSetProperName() {
        Aquarium aquarium = new Aquarium("Ivan", 10);
        Assert.assertEquals("Ivan", aquarium.getName());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testSetCapacityShouldThrow() {
        new Aquarium("Ivan", -9);
    }

    @Test
    public void testSetProperCapacity() {
        Aquarium aquarium = new Aquarium("Ivan", 10);
        Assert.assertEquals(10, aquarium.getCapacity());
    }

    @Test
    public void testShouldAddAFish() {
        Aquarium aquarium = new Aquarium("Ivan", 10);
        aquarium.add(new Fish("fdsf"));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddFishShouldFail() {
        Aquarium aquarium = new Aquarium("Ivan", 2);
        aquarium.add(new Fish("1"));
        aquarium.add(new Fish("2"));
        aquarium.add(new Fish("3"));
    }

    @Test
    public void testRemoveFish() {
        Aquarium aquarium = new Aquarium("Ivan", 2);
        aquarium.add(new Fish("1"));
        aquarium.add(new Fish("2"));
        aquarium.remove("2");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testRemoveFishShouldFail() {
        Aquarium aquarium = new Aquarium("Ivan", 2);
        aquarium.add(new Fish("1"));
        aquarium.add(new Fish("2"));
        aquarium.remove("3");
    }

    @Test
    public void testSellFish() {
        Aquarium aquarium = new Aquarium("Ivan", 2);
        aquarium.add(new Fish("1"));
        aquarium.add(new Fish("2"));
        aquarium.sellFish("2");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testSellFishShouldFail() {
        Aquarium aquarium = new Aquarium("Ivan", 2);
        aquarium.add(new Fish("1"));
        aquarium.add(new Fish("2"));
        aquarium.sellFish("32");
    }

    @Test
    public void testReport() {
        Aquarium aquarium = new Aquarium("Ivan", 3);
        aquarium.add(new Fish("1"));
        aquarium.add(new Fish("2"));
        aquarium.add(new Fish("32"));

        String expected = "Fish available at Ivan: 1, 2, 32";

        Assert.assertEquals(expected, aquarium.report());
    }
}

