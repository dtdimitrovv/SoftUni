package aquarium.core;

import aquarium.entities.aquariums.Aquarium;
import aquarium.entities.aquariums.FreshwaterAquarium;
import aquarium.entities.aquariums.SaltwaterAquarium;
import aquarium.entities.decorations.Decoration;
import aquarium.entities.decorations.Ornament;
import aquarium.entities.decorations.Plant;
import aquarium.entities.fish.Fish;
import aquarium.entities.fish.FreshwaterFish;
import aquarium.entities.fish.SaltwaterFish;
import aquarium.repositories.DecorationRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import static aquarium.common.ConstantMessages.*;
import static aquarium.common.ExceptionMessages.*;

public class ControllerImpl implements Controller {
    private DecorationRepository decorations;
    private List<Aquarium> aquariums;

    public ControllerImpl() {
        this.decorations = new DecorationRepository();
        this.aquariums = new ArrayList<>();
    }

    @Override
    public String addAquarium(String aquariumType, String aquariumName) {
        Aquarium aquarium;

        if (aquariumType.equals("FreshwaterAquarium")) {
            aquarium = new FreshwaterAquarium(aquariumName);
        } else if (aquariumType.equals("SaltwaterAquarium")) {
            aquarium = new SaltwaterAquarium(aquariumName);
        } else {
            throw new NullPointerException(INVALID_AQUARIUM_TYPE);
        }

        this.aquariums.add(aquarium);

        return String.format(SUCCESSFULLY_ADDED_AQUARIUM_TYPE, aquariumType);
    }

    @Override
    public String addDecoration(String type) {
        Decoration decoration;

        if (type.equals("Plant")) {
            decoration = new Plant();
        } else if (type.equals("Ornament")) {
            decoration = new Ornament();
        } else {
            throw new IllegalArgumentException(INVALID_DECORATION_TYPE);
        }

        this.decorations.add(decoration);

        return String.format(SUCCESSFULLY_ADDED_DECORATION_TYPE, type);
    }

    @Override
    public String insertDecoration(String aquariumName, String decorationType) {
        Decoration foundDecoration = this.decorations.findByType(decorationType);

        if (foundDecoration == null) {
            throw new IllegalArgumentException(String.format(NO_DECORATION_FOUND, decorationType));
        }

        this.decorations.remove(foundDecoration);

        for (Aquarium aquarium : this.aquariums) {
            if (aquarium.getName().equals(aquariumName)) {
                aquarium.addDecoration(foundDecoration);
            }
        }
        return String.format(SUCCESSFULLY_ADDED_DECORATION_IN_AQUARIUM, decorationType, aquariumName);
    }

    @Override
    public String addFish(String aquariumName, String fishType, String fishName, String fishSpecies, double price) {
        // Find the aquarium
        Aquarium aquarium = findAquarium(aquariumName);

        // Find the type of the fish we want to add
        Fish fishToAdd = getFishWithItsCorrectType(fishType, fishName, fishSpecies, price);

        // Check whether the type of fish in the aquarium matches our type
        assert aquarium != null;
        if (checkIfFishIsAppropriateForAquarium(aquarium, fishType)) {
            aquarium.addFish(fishToAdd);
        } else {
            throw new IllegalArgumentException(WATER_NOT_SUITABLE);
        }

        return String.format(SUCCESSFULLY_ADDED_FISH_IN_AQUARIUM, fishType, aquariumName);
    }

    private boolean checkIfFishIsAppropriateForAquarium(Aquarium aquarium, String fishType) {
        if (aquarium.getFish().isEmpty()) {
            return true;
        }

        String fishClass = fishType.replaceAll("Fish", "");

        for (Fish aquariumFish : aquarium.getFish()) {
            String aquariumFishClass = aquariumFish.getClass().getSimpleName().replaceAll("Fish", "");
            if (aquariumFishClass.equals(fishClass)) {
                return true;
            }
        }
        return false;
    }

    private Aquarium findAquarium(String aquariumName) {
        for (Aquarium currentAquarium : this.aquariums) {
            if (currentAquarium.getName().equals(aquariumName)) {
                return currentAquarium;
            }
        }
        return null;
    }

    private Fish getFishWithItsCorrectType(String fishType, String fishName, String fishSpecies, double price) {
        if (fishType.equals("FreshwaterFish")) {
            return new FreshwaterFish(fishName, fishSpecies, price);
        } else if (fishType.equals("SaltwaterFish")) {
            return new SaltwaterFish(fishName, fishSpecies, price);
        } else {
            throw new IllegalArgumentException(INVALID_FISH_TYPE);
        }
    }

    @Override
    public String feedFish(String aquariumName) {
        Aquarium aquarium = findAquarium(aquariumName);

        assert aquarium != null;
        aquarium.feed();

        return String.format(FISH_FED, aquarium.getFish().size());
    }

    @Override
    public String calculateValue(String aquariumName) {
        Aquarium aquarium = findAquarium(aquariumName);
        assert aquarium != null;

        double totalValue = aquarium.getDecorations().stream().mapToDouble(Decoration::getPrice).sum()
                + aquarium.getFish().stream().mapToDouble(Fish::getPrice).sum();

        return String.format(VALUE_AQUARIUM, aquariumName, totalValue);
    }

    @Override
    public String report() {
        return this.aquariums.stream().map(Aquarium::getInfo).collect(Collectors.joining(System.lineSeparator())).trim();
    }
}
